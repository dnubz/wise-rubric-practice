# WiSe feature learning guide

Start here. This folder teaches the current game using the supplied scoring workbook and the actual project code.

1. Read [Learning path](00-learning-path.md) to choose a manageable order.
2. Keep [Controls](01-controls.md) open while demonstrating the game.
3. Read a chapter below: player behavior → code flow → actual snippet → demonstration → a short explanation you can say aloud.
4. Open its linked project script or the included copy.
5. Use [Workbook and scoring](02-workbook-and-scoring.md) and the [rubric index](Rubric/README.md) to cover every requirement.

## Features

| Chapter | Learn |
| --- | --- |
| 00 | [Git, GitHub, and explaining optimization](Features/00-git-and-performance.md) |
| 01 | [OOP, ScriptableObjects, and event channels](Features/01-architecture.md) |
| 02 | [Title screen, Play, Continue, and Exit](Features/02-title-menu.md) |
| 03 | [Music, SFX, frame rate, resolution, and fullscreen](Features/03-settings.md) |
| 04 | [Three binary save slots and restoring a playthrough](Features/04-save-files.md) |
| 05 | [Movement, switching characters, HP/SP, EXP, and HUD](Features/05-movement-and-party.md) |
| 06 | [WiSe: cutting trees and cactus, and breaking decorations](Features/06-wise-exploration.md) |
| 07 | [RandaL: book preview, raycasts, and placement constraints](Features/07-randal-book.md) |
| 08 | [Druid: jumping, slow falling, and the pool cliff](Features/08-druid-gliding.md) |
| 09 | [NPC dialogue, proximity, shops, and challenge prompts](Features/09-npc-dialogue.md) |
| 10 | [Inventory, consumables, HP/SP preview, and Diamond](Features/10-items.md) |
| 11 | [Two equipment slots, stat differences, and removing gear](Features/11-equipment.md) |
| 12 | [Item/equipment shops and resource merchants](Features/12-shops.md) |
| 13 | [WFC, weighted entropy, seeded generation, and shoreline rules](Features/13-overworld-wfc.md) |
| 14 | [Infinite chunks, resources, buildings, NPCs, and decorations](Features/14-streaming-and-content.md) |
| 15 | [5×5 pools, swimming, obstacle chests, and the boat mismatch](Features/15-water-and-obstacles.md) |
| 16 | [Dungeon room graphs, chains, keys, and floor WFC](Features/16-dungeon-generation.md) |
| 17 | [Dungeon entry, room doors, keys, treasure, and breakables](Features/17-dungeon-travel-and-rooms.md) |
| 18 | [Exploration camera, zoom, overworld map, and dungeon reveal](Features/18-cameras-and-maps.md) |
| 19 | [Enemy FSM, navigation, Skeleton/Minion attacks, and variants](Features/19-enemies.md) |
| 20 | [Encounters, party turns, AP, cover, victory, and returns](Features/20-battle-system.md) |
| 21 | [WiSe battle skills: crescent, shields, dragon, and dodge](Features/21-wise-battle-skills.md) |
| 22 | [RandaL battle skills: lock-on, SP buff, portal, and barrage](Features/22-randal-battle-skills.md) |
| 23 | [Druid battle skills: healing burst, pull, teleport, and rhythm](Features/23-druid-battle-skills.md) |
| 24 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](Features/24-jevil-boss.md) |
| 25 | [Berdly chemistry battle: answers, timer, attack, and defend](Features/25-berdly-minigame.md) |
| 26 | [The shared molecule and dungeon naming algorithm](Features/26-iupac-algorithm.md) |
| 27 | [Pink rhythm: beatmap parsing, tap/hold judgements, and score](Features/27-rhythm-game.md) |
| 28 | [Cheat console, area checks, and all supported commands](Features/28-cheats.md) |
| 29 | [Audio routing, footsteps, particles, highlights, and UI feedback](Features/29-audio-and-visual-feedback.md) |
| 30 | [What is confirmed, what needs a playtest, and known gaps](Features/30-verification-and-gaps.md) |
| 31 | [In-game menu, Resources, Stats, previews, and Save & Quit](Features/31-game-menu.md) |

## Reference files

- [Script reference](ScriptReference/README.md): all project gameplay/tool scripts, class names, entry points, scene attachment evidence, and links.
- [Asset values](03-asset-values.md): saved character/item/equipment/skill/settings data. Distinguishes configured assets from class defaults.
- [Verification checklist](04-demonstration-checklist.md): an organized practice run.
- [Glossary](05-glossary.md): small definitions used throughout the guide.
- [Sources and limitations](06-sources-and-limits.md): scope, known mismatches, and provenance.
- [Script copies](Scripts/README.md): portable source snapshots, not a replacement Unity project.

## Read the known gaps

The current pool center creates a glide cliff and chest instead of the required boat/deck. The audio mapping has three dry walking clips and swimming audio, but no distinct water walking clip. Rain/blossom weather and title character/Play animations need direct inspection. Read [verification and gaps](Features/30-verification-and-gaps.md) before describing the project as complete.

No gameplay code or workbook content was changed. The script copies reflect the local working tree at documentation time, including existing BattleCamera/BattleController edits. No new Unity playtest/build was run for this documentation task.
