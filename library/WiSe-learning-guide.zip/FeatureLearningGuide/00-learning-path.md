# A manageable learning path

[Guide home](README.md)

## First pass: understand the player experience

Read [Controls](01-controls.md), then chapters 02–12. Start the title, create/use a spare save slot, explore with each character, talk to NPCs, and use Items/Equipment/Shop. For each feature, answer: **What triggers it? What changes? What feedback shows the change?**

## Second pass: understand world generation

Read 13–18 and 26. Draw a 5×5 water pool with two rings. Trace one WFC collapse/propagation step. Draw a simple room tree, identify its parent chain and branch degree, then explain where keys and locks go. Distinguish the room graph from floor WFC.

## Third pass: understand battle

Read 19–24. Trace encounter hit → BattleSession → layout setup → player turn → enemy turn → result → return. Use the skill table for each character and demonstrate SP/AP/cooldown gates. Explain shield consumption and projectile interception before discussing fancy effects.

## Fourth pass: understand minigames

Read 25–28. Work through one simple molecule naming example, then one Berdly attack/defend turn. For rhythm, calculate one note's score and one half-completed hold. Explain which minigame unlocks which ultimate and why dungeon entry depends on both.

## Fifth pass: prepare the explanation criteria

Read 00, 01, 03, 04, 07, 13, 19, 26, and 29. These cover Git, OOP, settings persistence, binary saves, raycasts, WFC, FSM, naming, and feedback. Use the [demonstration checklist](04-demonstration-checklist.md) and the workbook row pages for completeness.

## For each chapter

1. Read only its plain explanation first.
2. Find the named class/method in the linked script.
3. Trace the call into its next owner (data, character state, UI, or session).
4. Demonstrate its normal behavior and one blocked/edge case.
5. Say the short answer aloud in your own words.

Do not memorize an entire 1,000-line controller. Read the exact branch for the selected character/skill, then inspect the shared helper it calls.
