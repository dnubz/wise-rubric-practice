# Editor scripts

[Script index](README.md) · [Guide home](../README.md)

These are editor checks, setup tools, builders, and probes. Setup/Builder tools can alter scene or asset files. No editor helper was run for this documentation task.

## BattleArenaSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleArenaSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattleArenaSetup.cs)

**Declared types:** `BattleArenaSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Battle/Expand Arena to 66m`.

**Entry points and methods:**

- [BattleArenaSetup (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleArenaSetup.cs:15>).
- [Check (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleArenaSetup.cs:16>).
- [Apply (line 25)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleArenaSetup.cs:25>).
- [Spread (line 56)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleArenaSetup.cs:56>).

## BattleChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattleChecks.cs)

**Declared types:** `BattleChecks`.

**Teaching:** [What is confirmed, what needs a playtest, and known gaps](../Features/30-verification-and-gaps.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [BattleChecks (line 25)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:25>).
- [Check (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:26>).
- [Run (line 51)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:51>).
- [DungeonTravel (line 172)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:172>).
- [ExtraSkills (line 209)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:209>).
- [Set (line 319)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:319>).
- [Warp (line 320)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:320>).
- [Complete (line 325)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:325>).
- [DodgeInput (line 326)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:326>).
- [Capture (line 338)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:338>).
- [Require (line 352)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:352>).
- [Log (line 353)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleChecks.cs:353>).

## BattleCoverPolishChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattleCoverPolishChecks.cs)

**Declared types:** `BattleCoverPolishChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [BattleCoverPolishChecks (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishChecks.cs:16>).
- [Check (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishChecks.cs:17>).
- [Finish (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishChecks.cs:37>).
- [Require (line 38)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishChecks.cs:38>).
- [BlocksHighRay (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishChecks.cs:39>).
- [Run (line 44)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishChecks.cs:44>).

## BattleCoverPolishSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattleCoverPolishSetup.cs)

**Declared types:** `BattleCoverPolishSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [BattleCoverPolishSetup (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishSetup.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishSetup.cs:15>).
- [Build (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishSetup.cs:24>).
- [Debris (line 64)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleCoverPolishSetup.cs:64>).

## BattleDragonBuilder.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattleDragonBuilder.cs)

**Declared types:** `BattleDragonBuilder`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Build (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:11>).
- [FlightAnimation (line 56)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:56>).
- [Curve (line 74)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:74>).
- [Wing (line 80)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:80>).
- [Cone (line 87)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:87>).
- [SaveMesh (line 94)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:94>).
- [Joint (line 100)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:100>).
- [MeshPart (line 102)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:102>).
- [Sphere (line 104)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:104>).
- [Tube (line 106)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:106>).
- [Material (line 108)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleDragonBuilder.cs:108>).

## BattleMovementChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleMovementChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattleMovementChecks.cs)

**Declared types:** `BattleMovementChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [BattleMovementChecks (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleMovementChecks.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleMovementChecks.cs:15>).
- [Finish (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleMovementChecks.cs:34>).
- [Require (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleMovementChecks.cs:39>).
- [Run (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleMovementChecks.cs:40>).

## BattlePresentationChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattlePresentationChecks.cs)

**Declared types:** `BattlePresentationChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [BattlePresentationChecks (line 25)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:25>).
- [Check (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:26>).
- [Log (line 49)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:49>).
- [Require (line 50)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:50>).
- [RunAudio (line 51)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:51>).
- [Run (line 94)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:94>).
- [CheckExpandedLayouts (line 169)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:169>).
- [CheckMovementEdges (line 203)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:203>).
- [Capture (line 235)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationChecks.cs:235>).

## BattlePresentationSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattlePresentationSetup.cs)

**Declared types:** `BattlePresentationSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Battle/Make Jevil Arena Square`, `WiSe/Battle/Update Camera and Skill Presentation`.

**Entry points and methods:**

- [BattlePresentationSetup (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:20>).
- [Check (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:21>).
- [ApplySquareBoss (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:37>).
- [Apply (line 55)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:55>).
- [Place (line 148)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:148>).
- [Stretch (line 150)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:150>).
- [FitBar (line 152)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:152>).
- [Image (line 157)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:157>).
- [Text (line 159)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:159>).
- [Area (line 166)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattlePresentationSetup.cs:166>).

## BattleSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BattleSetup.cs)

**Declared types:** `BattleSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Battle/Set Up Battle`.

**Entry points and methods:**

- [BattleSetup (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:28>).
- [Check (line 29)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:29>).
- [Build (line 101)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:101>).
- [Enemy (line 171)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:171>).
- [Layout (line 201)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:201>).
- [Skills (line 233)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:233>).
- [Input (line 247)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:247>).
- [BuildHUD (line 256)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:256>).
- [BuildBossGame (line 292)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:292>).
- [SetupHealer (line 304)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:304>).
- [AddAnimations (line 313)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:313>).
- [Projectile (line 330)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:330>).
- [AreaEffect (line 336)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:336>).
- [StatusEffect (line 342)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:342>).
- [Ring (line 364)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:364>).
- [Dragon (line 374)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:374>).
- [Impact (line 395)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:395>).
- [HealthUI (line 402)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:402>).
- [Popup (line 409)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:409>).
- [Line (line 416)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:416>).
- [Material (line 418)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:418>).
- [Part (line 420)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:420>).
- [Joint (line 422)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:422>).
- [Bounds (line 423)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:423>).
- [Fit (line 425)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:425>).
- [Audio (line 428)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:428>).
- [SpriteAsset (line 429)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:429>).
- [FindAudio (line 438)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:438>).
- [Canvas (line 440)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:440>).
- [Rect (line 442)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:442>).
- [Image (line 444)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:444>).
- [Box (line 446)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:446>).
- [Text (line 448)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:448>).
- [Bar (line 450)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:450>).
- [Button (line 452)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:452>).
- [Stretch (line 454)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BattleSetup.cs:454>).

## BerdlyFeedbackChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs)

**Declared types:** `BerdlyFeedbackChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Berdly/Validate Battle Feedback`.

**Entry points and methods:**

- [BerdlyFeedbackChecks (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:17>).
- [Poll (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:18>).
- [Run (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:26>).
- [State (line 115)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:115>).
- [Child (line 123)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:123>).
- [CheckGeometry (line 124)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:124>).
- [Capture (line 134)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:134>).
- [Call (line 148)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:148>).
- [Set (line 150)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:150>).
- [Value (line 151)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:151>).
- [Require (line 152)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyFeedbackChecks.cs:152>).

## BerdlyPracticeChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyPracticeChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/BerdlyPracticeChecks.cs)

**Declared types:** `BerdlyPracticeChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Berdly/Validate Practice Questions`.

**Entry points and methods:**

- [BerdlyPracticeChecks (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyPracticeChecks.cs:16>).
- [Poll (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyPracticeChecks.cs:17>).
- [Run (line 25)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyPracticeChecks.cs:25>).
- [CapturePreview (line 80)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyPracticeChecks.cs:80>).
- [Require (line 101)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/BerdlyPracticeChecks.cs:101>).

## CharacterHighlightChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CharacterHighlightChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/CharacterHighlightChecks.cs)

**Declared types:** `CharacterHighlightChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Characters/Check Highlight Reactivation`.

**Entry points and methods:**

- [CharacterHighlightChecks (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CharacterHighlightChecks.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CharacterHighlightChecks.cs:15>).
- [Run (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CharacterHighlightChecks.cs:23>).
- [Set (line 72)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CharacterHighlightChecks.cs:72>).
- [Call (line 73)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CharacterHighlightChecks.cs:73>).
- [Require (line 74)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CharacterHighlightChecks.cs:74>).

## CheatConsoleSceneBuilder.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CheatConsoleSceneBuilder.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/CheatConsoleSceneBuilder.cs)

**Declared types:** `CheatConsoleSceneBuilder`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Add Cheat Panel to GameScene`.

**Entry points and methods:**

- [CheatConsoleSceneBuilder (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CheatConsoleSceneBuilder.cs:16>).
- [CheckRequest (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CheatConsoleSceneBuilder.cs:18>).
- [CreatePanel (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/CheatConsoleSceneBuilder.cs:37>).

## ConsumableMenuChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/ConsumableMenuChecks.cs)

**Declared types:** `ConsumableMenuChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [ConsumableMenuChecks (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs:21>).
- [Check (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs:22>).
- [Run (line 48)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs:48>).
- [ClearConsumables (line 149)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs:149>).
- [CaptureError (line 154)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs:154>).
- [Capture (line 158)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs:158>).
- [Require (line 181)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuChecks.cs:181>).

## ConsumableMenuSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/ConsumableMenuSetup.cs)

**Declared types:** `ConsumableMenuSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Set Up Consumable Row`.

**Entry points and methods:**

- [ConsumableMenuSetup (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuSetup.cs:16>).
- [Check (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuSetup.cs:17>).
- [Build (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/ConsumableMenuSetup.cs:26>).

## DruidPullChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DruidPullChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DruidPullChecks.cs)

**Declared types:** `DruidPullChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [DruidPullChecks (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DruidPullChecks.cs:16>).
- [Check (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DruidPullChecks.cs:17>).
- [Finish (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DruidPullChecks.cs:37>).
- [Require (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DruidPullChecks.cs:39>).
- [Run (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DruidPullChecks.cs:40>).

## DungeonArrivalChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonArrivalChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonArrivalChecks.cs)

**Declared types:** `DungeonArrivalChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [DungeonArrivalChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonArrivalChecks.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonArrivalChecks.cs:20>).
- [Finish (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonArrivalChecks.cs:39>).
- [Require (line 41)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonArrivalChecks.cs:41>).
- [Run (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonArrivalChecks.cs:43>).
- [DoorPixel (line 129)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonArrivalChecks.cs:129>).

## DungeonBreakingChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonBreakingChecks.cs)

**Declared types:** `DungeonBreakingChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Breaking`.

**Entry points and methods:**

- [DungeonBreakingChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:20>).
- [Run (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:32>).
- [SavePreview (line 147)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:147>).
- [Get (line 167)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:167>).
- [Set (line 168)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:168>).
- [Invoke (line 169)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:169>).
- [Require (line 170)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingChecks.cs:170>).

## DungeonBreakingSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonBreakingSetup.cs)

**Declared types:** `DungeonBreakingSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Dungeon Breaking`.

**Entry points and methods:**

- [DungeonBreakingSetup (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingSetup.cs:15>).
- [Check (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingSetup.cs:16>).
- [Build (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonBreakingSetup.cs:28>).

## DungeonCameraChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonCameraChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonCameraChecks.cs)

**Declared types:** `DungeonCameraChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Camera`.

**Entry points and methods:**

- [DungeonCameraChecks (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonCameraChecks.cs:20>).
- [Check (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonCameraChecks.cs:21>).
- [Run (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonCameraChecks.cs:43>).
- [Set (line 147)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonCameraChecks.cs:147>).
- [Invoke (line 148)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonCameraChecks.cs:148>).
- [Require (line 149)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonCameraChecks.cs:149>).

## DungeonDoorInteractionChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs)

**Declared types:** `DungeonDoorInteractionChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Door Interactions`.

**Entry points and methods:**

- [DungeonDoorInteractionChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:20>).
- [Run (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:32>).
- [Table (line 216)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:216>).
- [Set (line 217)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:217>).
- [MoveGate (line 218)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:218>).
- [RefreshFeedback (line 219)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:219>).
- [Require (line 220)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonDoorInteractionChecks.cs:220>).

## DungeonEntrancePromptChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs)

**Declared types:** `DungeonEntrancePromptChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [DungeonEntrancePromptChecks (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs:19>).
- [Finish (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs:37>).
- [Require (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs:42>).
- [Prompt (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs:43>).
- [Refresh (line 45)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs:45>).
- [Run (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntrancePromptChecks.cs:46>).

## DungeonEntryUIBuilder.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs)

**Declared types:** `DungeonEntryUIBuilder`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Remove Dungeon Entry Dots`, `WiSe/UI/Add Dungeon Entry UI to GameScene`.

**Entry points and methods:**

- [DungeonEntryUIBuilder (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:22>).
- [Check (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:23>).
- [RemoveDots (line 58)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:58>).
- [Build (line 71)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:71>).
- [PartyCard (line 149)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:149>).
- [StatBar (line 171)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:171>).
- [ActionButton (line 183)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:183>).
- [Rect (line 196)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:196>).
- [Stretch (line 202)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:202>).
- [Image (line 206)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:206>).
- [RoundedBox (line 210)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:210>).
- [Border (line 216)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:216>).
- [Label (line 221)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:221>).
- [Assign (line 227)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:227>).
- [SpriteAsset (line 230)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:230>).
- [RoundedAlpha (line 249)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:249>).
- [InnerAlpha (line 255)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonEntryUIBuilder.cs:255>).

## DungeonFeedbackChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonFeedbackChecks.cs)

**Declared types:** `DungeonFeedbackChecks`, `ApproachNormalProbe`, `ApproachInteractProbe`, `ApproachChallengeProbe`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Feedback`.

**Entry points and methods:**

- [DungeonFeedbackChecks (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs:17>).
- [Check (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs:18>).
- [Run (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs:28>).
- [CheckDungeonNPCs (line 86)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs:86>).
- [Table (line 95)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs:95>).
- [CheckApproach (line 96)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs:96>).
- [Require (line 117)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackChecks.cs:117>).

## DungeonFeedbackSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonFeedbackSetup.cs)

**Declared types:** `DungeonFeedbackSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Dungeon Feedback`.

**Entry points and methods:**

- [DungeonFeedbackSetup (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackSetup.cs:15>).
- [Check (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackSetup.cs:16>).
- [Build (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackSetup.cs:27>).
- [Keyframe (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackSetup.cs:34>).
- [Sound (line 60)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackSetup.cs:60>).
- [AudibleStart (line 61)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonFeedbackSetup.cs:61>).

## DungeonGenerationChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonGenerationChecks.cs)

**Declared types:** `DungeonGenerationChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Generation`.

**Entry points and methods:**

- [Run (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs:11>).
- [CheckFloor (line 36)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs:36>).
- [Check (line 54)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs:54>).
- [CanExploreAll (line 126)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs:126>).
- [Locants (line 164)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs:164>).
- [Signature (line 170)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs:170>).
- [Require (line 171)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonGenerationChecks.cs:171>).

## DungeonInteractionUIBuilder.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs)

**Declared types:** `DungeonInteractionUIBuilder`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Set Up Dungeon Interaction UI`.

**Entry points and methods:**

- [DungeonInteractionUIBuilder (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs:21>).
- [Check (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs:22>).
- [Build (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs:34>).
- [Canvas (line 114)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs:114>).
- [AddGateHighlight (line 123)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs:123>).
- [Rect (line 171)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs:171>).
- [Shape (line 177)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonInteractionUIBuilder.cs:177>).

## DungeonJumpChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonJumpChecks.cs)

**Declared types:** `DungeonJumpChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [DungeonJumpChecks (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs:20>).
- [Check (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs:21>).
- [Finish (line 41)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs:41>).
- [Require (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs:42>).
- [Set (line 44)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs:44>).
- [Key (line 45)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs:45>).
- [Run (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonJumpChecks.cs:46>).

## DungeonLightingChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonLightingChecks.cs)

**Declared types:** `DungeonLightingChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Lighting`.

**Entry points and methods:**

- [DungeonLightingChecks (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:21>).
- [Check (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:22>).
- [Run (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:34>).
- [Render (line 142)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:142>).
- [Table (line 151)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:151>).
- [Get (line 152)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:152>).
- [Set (line 153)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:153>).
- [Invoke (line 154)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:154>).
- [Require (line 155)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingChecks.cs:155>).

## DungeonLightingSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonLightingSetup.cs)

**Declared types:** `DungeonLightingSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Dungeon Lighting`.

**Entry points and methods:**

- [DungeonLightingSetup (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingSetup.cs:17>).
- [Check (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingSetup.cs:18>).
- [Build (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonLightingSetup.cs:30>).

## DungeonPolishChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonPolishChecks.cs)

**Declared types:** `DungeonPolishChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Polish`.

**Entry points and methods:**

- [DungeonPolishChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishChecks.cs:19>).
- [CheckRequest (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishChecks.cs:20>).
- [Run (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishChecks.cs:32>).
- [Capture (line 112)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishChecks.cs:112>).
- [Require (line 119)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishChecks.cs:119>).

## DungeonPolishSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonPolishSetup.cs)

**Declared types:** `DungeonPolishSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Dungeon/Set Up Arrival and Skeleton`.

**Entry points and methods:**

- [DungeonPolishSetup (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:16>).
- [Check (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:17>).
- [Build (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:28>).
- [Clip (line 51)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:51>).
- [AttachSkeleton (line 61)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:61>).
- [FitSkeletonCollider (line 98)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:98>).
- [Texture (line 104)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:104>).
- [BuildTitle (line 105)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:105>).
- [Rect (line 139)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonPolishSetup.cs:139>).

## DungeonSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonSetup.cs)

**Declared types:** `DungeonSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Dungeon`.

**Entry points and methods:**

- [DungeonSetup (line 12)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:12>).
- [Check (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:13>).
- [Build (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:32>).
- [Material (line 83)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:83>).
- [AssignModels (line 96)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:96>).
- [ModelPrefab (line 103)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:103>).
- [FloorPrefab (line 130)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:130>).
- [ApplyFloorMaterials (line 153)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonSetup.cs:153>).

## DungeonTravelFeedbackChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs)

**Declared types:** `DungeonTravelFeedbackChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [DungeonTravelFeedbackChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs:20>).
- [Finish (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs:43>).
- [Require (line 45)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs:45>).
- [Set (line 47)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs:47>).
- [Run (line 48)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs:48>).
- [AudibleDelay (line 114)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackChecks.cs:114>).

## DungeonTravelFeedbackSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonTravelFeedbackSetup.cs)

**Declared types:** `DungeonTravelFeedbackSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [DungeonTravelFeedbackSetup (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackSetup.cs:16>).
- [Check (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackSetup.cs:17>).
- [Build (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackSetup.cs:27>).
- [ImmediateClip (line 38)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackSetup.cs:38>).
- [BuildFade (line 74)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonTravelFeedbackSetup.cs:74>).

## DungeonVariationChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonVariationChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/DungeonVariationChecks.cs)

**Declared types:** `DungeonVariationChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Dungeon Variation and Saves`.

**Entry points and methods:**

- [DungeonVariationChecks (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonVariationChecks.cs:18>).
- [Poll (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonVariationChecks.cs:19>).
- [Run (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonVariationChecks.cs:27>).
- [Snapshot (line 101)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonVariationChecks.cs:101>).
- [Require (line 106)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/DungeonVariationChecks.cs:106>).

## EncounterNavigationChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EncounterNavigationChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/EncounterNavigationChecks.cs)

**Declared types:** `EncounterNavigationChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [EncounterNavigationChecks (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EncounterNavigationChecks.cs:20>).
- [Check (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EncounterNavigationChecks.cs:21>).
- [Finish (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EncounterNavigationChecks.cs:40>).
- [Require (line 41)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EncounterNavigationChecks.cs:41>).
- [Flat (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EncounterNavigationChecks.cs:42>).
- [Run (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EncounterNavigationChecks.cs:43>).

## EnemyCriteriaSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyCriteriaSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/EnemyCriteriaSetup.cs)

**Declared types:** `EnemyCriteriaSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Enemies/Set Up Enemy Criteria`.

**Entry points and methods:**

- [EnemyCriteriaSetup (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyCriteriaSetup.cs:13>).
- [Check (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyCriteriaSetup.cs:14>).
- [Build (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyCriteriaSetup.cs:22>).
- [Leg (line 84)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyCriteriaSetup.cs:84>).

## EnemyRequirementsChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/EnemyRequirementsChecks.cs)

**Declared types:** `EnemyRequirementsChecks`.

**Teaching:** [What is confirmed, what needs a playtest, and known gaps](../Features/30-verification-and-gaps.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Enemies/Check Enemy Criteria`.

**Entry points and methods:**

- [EnemyRequirementsChecks (line 25)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:25>).
- [Request (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:27>).
- [Check (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:28>).
- [Finish (line 59)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:59>).
- [Log (line 67)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:67>).
- [Require (line 69)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:69>).
- [Flat (line 70)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:70>).
- [Warp (line 71)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:71>).
- [Frames (line 72)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:72>).
- [Run (line 74)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:74>).
- [Complete (line 186)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:186>).
- [Capture (line 187)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/EnemyRequirementsChecks.cs:187>).

## GameMenuChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/GameMenuChecks.cs)

**Declared types:** `GameMenuChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [GameMenuChecks (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs:23>).
- [Check (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs:24>).
- [Run (line 48)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs:48>).
- [DisableNPCs (line 121)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs:121>).
- [CaptureError (line 123)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs:123>).
- [Capture (line 127)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs:127>).
- [Require (line 153)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuChecks.cs:153>).

## GameMenuSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/GameMenuSetup.cs)

**Declared types:** `GameMenuSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Set Up Other Game Menu Tabs`.

**Entry points and methods:**

- [GameMenuSetup (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:22>).
- [Check (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:23>).
- [Build (line 86)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:86>).
- [BuildResources (line 144)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:144>).
- [BuildStats (line 162)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:162>).
- [BuildSettings (line 200)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:200>).
- [BuildQuit (line 216)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:216>).
- [BuildContinueButton (line 225)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:225>).
- [SetupMixer (line 245)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:245>).
- [Rect (line 267)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:267>).
- [Image (line 272)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:272>).
- [Box (line 274)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:274>).
- [Label (line 279)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:279>).
- [Action (line 286)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:286>).
- [Filled (line 292)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:292>).
- [Bar (line 298)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:298>).
- [Slider (line 304)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:304>).
- [CopyButtonFont (line 319)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:319>).
- [Polish (line 326)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:326>).
- [Assign (line 345)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:345>).
- [AssignArray (line 346)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/GameMenuSetup.cs:346>).

## InteractionPromptChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/InteractionPromptChecks.cs)

**Declared types:** `InteractionPromptChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [InteractionPromptChecks (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs:18>).
- [Update (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs:19>).
- [Finish (line 38)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs:38>).
- [Require (line 45)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs:45>).
- [Set (line 47)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs:47>).
- [Run (line 48)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs:48>).
- [PreviewPool (line 172)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptChecks.cs:172>).

## InteractionPromptSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/InteractionPromptSetup.cs)

**Declared types:** `InteractionPromptSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Set Up Sprite Interaction Prompts`.

**Entry points and methods:**

- [InteractionPromptSetup (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:15>).
- [Build (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:30>).
- [Rect (line 90)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:90>).
- [Set (line 96)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:96>).
- [BuildOverlay (line 101)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:101>).
- [BuildCliff (line 119)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:119>).
- [AddRock (line 161)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:161>).
- [BoundsFor (line 185)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:185>).
- [Cube (line 195)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/InteractionPromptSetup.cs:195>).

## JevilPatternChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/JevilPatternChecks.cs)

**Declared types:** `JevilPatternChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `Tools/WiSe/Check Jevil Pattern 3`.

**Entry points and methods:**

- [JevilPatternChecks (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:32>).
- [Request (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:34>).
- [Check (line 35)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:35>).
- [Begin (line 57)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:57>).
- [Frame (line 77)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:77>).
- [Require (line 101)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:101>).
- [Field (line 122)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:122>).
- [CheckMotion (line 123)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:123>).
- [CheckCollision (line 137)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:137>).
- [Capture (line 150)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:150>).
- [Finish (line 162)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:162>).
- [Require (line 169)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/JevilPatternChecks.cs:169>).

## MarioChartPreviewChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/MarioChartPreviewChecks.cs)

**Declared types:** `MarioChartPreviewChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [MarioChartPreviewChecks (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewChecks.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewChecks.cs:15>).
- [Run (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewChecks.cs:24>).
- [Require (line 76)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewChecks.cs:76>).

## MarioChartPreviewSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/MarioChartPreviewSetup.cs)

**Declared types:** `MarioChartPreviewSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Mario Note Speed to 450`, `WiSe/Enable Mario 10 Second Chart Preview`.

**Entry points and methods:**

- [MarioChartPreviewSetup (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewSetup.cs:15>).
- [Check (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewSetup.cs:16>).
- [SetNoteSpeed (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewSetup.cs:34>).
- [ExportOpening (line 50)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewSetup.cs:50>).
- [Build (line 59)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioChartPreviewSetup.cs:59>).

## MarioFullChartSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/MarioFullChartSetup.cs)

**Declared types:** `MarioFullChartSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Enable Mario Full Rainbow Road Chart`.

**Entry points and methods:**

- [MarioFullChartSetup (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs:19>).
- [Build (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs:37>).
- [ValidateChart (line 61)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs:61>).
- [CheckPlayMode (line 90)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs:90>).
- [SetClockAndUpdate (line 136)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs:136>).
- [Require (line 142)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioFullChartSetup.cs:142>).

## MarioIdleSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioIdleSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/MarioIdleSetup.cs)

**Declared types:** `MarioIdleSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Mario Idle Animation`.

**Entry points and methods:**

- [MarioIdleSetup (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioIdleSetup.cs:16>).
- [Check (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioIdleSetup.cs:17>).
- [Build (line 33)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioIdleSetup.cs:33>).
- [AssignAnimator (line 76)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioIdleSetup.cs:76>).
- [Preview (line 89)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MarioIdleSetup.cs:89>).

## MenuStatBarChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/MenuStatBarChecks.cs)

**Declared types:** `MenuStatBarChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Check Menu Stat Bars`.

**Entry points and methods:**

- [MenuStatBarChecks (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:17>).
- [Check (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:18>).
- [Run (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:26>).
- [Child (line 93)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:93>).
- [Bar (line 95)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:95>).
- [CheckMesh (line 103)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:103>).
- [Set (line 121)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:121>).
- [Call (line 122)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:122>).
- [Require (line 123)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MenuStatBarChecks.cs:123>).

## MinionProjectileSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MinionProjectileSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/MinionProjectileSetup.cs)

**Declared types:** `MinionProjectileSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Minion Skewer Ball Projectile`.

**Entry points and methods:**

- [MinionProjectileSetup (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MinionProjectileSetup.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MinionProjectileSetup.cs:15>).
- [BuildPrefab (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/MinionProjectileSetup.cs:28>).

## NPCDialogueChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/NPCDialogueChecks.cs)

**Declared types:** `NPCDialogueChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate NPC Dialogue Bubbles`.

**Entry points and methods:**

- [NPCDialogueChecks (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueChecks.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueChecks.cs:19>).
- [Run (line 29)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueChecks.cs:29>).
- [Table (line 93)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueChecks.cs:93>).
- [Require (line 94)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueChecks.cs:94>).

## NPCDialogueSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/NPCDialogueSetup.cs)

**Declared types:** `NPCDialogueSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Fit NPC Dialogue Text and Use MedievalSharp`, `WiSe/UI/Set Up NPC Dialogue Bubbles`.

**Entry points and methods:**

- [NPCDialogueSetup (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs:19>).
- [UpdateDialogueText (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs:34>).
- [Build (line 50)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs:50>).
- [Style (line 75)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs:75>).
- [StyleText (line 99)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs:99>).
- [SaveDungeonNPC (line 123)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCDialogueSetup.cs:123>).

## NPCShopChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/NPCShopChecks.cs)

**Declared types:** `NPCShopChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [NPCShopChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs:20>).
- [Run (line 44)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs:44>).
- [Configure (line 128)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs:128>).
- [PressF (line 134)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs:134>).
- [Capture (line 135)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs:135>).
- [Require (line 159)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopChecks.cs:159>).

## NPCShopSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/NPCShopSetup.cs)

**Declared types:** `NPCShopSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/UI/Set Up Resource Merchants`.

**Entry points and methods:**

- [NPCShopSetup (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:22>).
- [Check (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:23>).
- [Build (line 33)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:33>).
- [AddPrompts (line 113)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:113>).
- [BuildPanel (line 127)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:127>).
- [Action (line 147)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:147>).
- [Rect (line 157)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:157>).
- [Stretch (line 162)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:162>).
- [PlainImage (line 163)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:163>).
- [Box (line 165)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:165>).
- [Label (line 167)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:167>).
- [Assign (line 175)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/NPCShopSetup.cs:175>).

## OverworldArrivalChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldArrivalChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldArrivalChecks.cs)

**Declared types:** `OverworldArrivalChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Overworld Arrival Title`.

**Entry points and methods:**

- [OverworldArrivalChecks (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldArrivalChecks.cs:15>).
- [Poll (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldArrivalChecks.cs:16>).
- [Run (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldArrivalChecks.cs:24>).
- [Render (line 49)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldArrivalChecks.cs:49>).
- [Require (line 64)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldArrivalChecks.cs:64>).

## OverworldAtmosphereChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs)

**Declared types:** `OverworldAtmosphereChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [OverworldAtmosphereChecks (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs:17>).
- [Check (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs:18>).
- [Run (line 31)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs:31>).
- [CheckAudio (line 90)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs:90>).
- [Capture (line 128)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs:128>).
- [Require (line 141)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereChecks.cs:141>).

## OverworldAtmosphereSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs)

**Declared types:** `OverworldAtmosphereSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Overworld Sounds and Decoration`.

**Entry points and methods:**

- [OverworldAtmosphereSetup (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs:19>).
- [Build (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs:30>).
- [AssignArray (line 89)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs:89>).
- [Decoration (line 94)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs:94>).
- [TryGetBounds (line 133)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs:133>).
- [Step (line 144)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldAtmosphereSetup.cs:144>).

## OverworldMusicChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldMusicChecks.cs)

**Declared types:** `OverworldMusicChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Overworld NPC Music (Play Mode)`.

**Entry points and methods:**

- [OverworldMusicChecks (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicChecks.cs:15>).
- [Check (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicChecks.cs:16>).
- [Run (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicChecks.cs:26>).
- [Get (line 88)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicChecks.cs:88>).
- [Tick (line 89)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicChecks.cs:89>).
- [Require (line 90)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicChecks.cs:90>).

## OverworldMusicSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldMusicSetup.cs)

**Declared types:** `OverworldMusicSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Overworld and NPC Music`.

**Entry points and methods:**

- [OverworldMusicSetup (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicSetup.cs:17>).
- [Check (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicSetup.cs:18>).
- [Build (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicSetup.cs:28>).
- [Clip (line 64)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicSetup.cs:64>).
- [Source (line 70)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicSetup.cs:70>).
- [SetTheme (line 78)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldMusicSetup.cs:78>).

## OverworldObstacleChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldObstacleChecks.cs)

**Declared types:** `OverworldObstacleChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [OverworldObstacleChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:20>).
- [Finish (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:39>).
- [Require (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:40>).
- [Get (line 41)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:41>).
- [Set (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:42>).
- [Invoke (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:43>).
- [Run (line 45)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:45>).
- [Stand (line 130)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:130>).
- [JumpTo (line 136)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:136>).
- [CrossGap (line 162)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleChecks.cs:162>).

## OverworldObstacleSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldObstacleSetup.cs)

**Declared types:** `OverworldObstacleSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Overworld Platform Challenge`.

**Entry points and methods:**

- [OverworldObstacleSetup (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:15>).
- [Check (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:16>).
- [Build (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:26>).
- [MakeBook (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:46>).
- [MakeObstacle (line 57)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:57>).
- [Vector3 (line 76)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:76>).
- [Load (line 99)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:99>).
- [Cube (line 100)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:100>).
- [AddModel (line 105)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldObstacleSetup.cs:105>).

## OverworldSeedChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/OverworldSeedChecks.cs)

**Declared types:** `OverworldSeedChecks`.

**Teaching:** [What is confirmed, what needs a playtest, and known gaps](../Features/30-verification-and-gaps.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [OverworldSeedChecks (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:20>).
- [Set (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:34>).
- [Require (line 35)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:35>).
- [Run (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:37>).
- [Clear (line 141)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:141>).
- [Compare (line 155)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:155>).
- [ValidatePool (line 163)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:163>).
- [CheckLootAndDrops (line 176)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:176>).
- [F (line 202)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:202>).
- [V (line 203)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:203>).
- [Q (line 204)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/OverworldSeedChecks.cs:204>).

## PinkMarioChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/PinkMarioChecks.cs)

**Declared types:** `PinkMarioChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Pink Mario Model and Audio`.

**Entry points and methods:**

- [PinkMarioChecks (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioChecks.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioChecks.cs:15>).
- [Run (line 25)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioChecks.cs:25>).
- [Require (line 70)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioChecks.cs:70>).

## PinkMarioSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/PinkMarioSetup.cs)

**Declared types:** `PinkMarioSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Set Up Pink Mario Model and Music`.

**Entry points and methods:**

- [PinkMarioSetup (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs:19>).
- [Check (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs:20>).
- [Build (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs:30>).
- [CueStarts (line 131)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs:131>).
- [FitBeatmap (line 151)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs:151>).
- [BoundsOf (line 176)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs:176>).
- [Fit (line 181)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkMarioSetup.cs:181>).

## PinkRhythmUIBuilder.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs)

**Declared types:** `PinkRhythmUIBuilder`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Complete Pink Rhythm UI`.

**Entry points and methods:**

- [PinkRhythmUIBuilder (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:24>).
- [ApplyRequestedBuild (line 29)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:29>).
- [Build (line 72)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:72>).
- [BuildStamina (line 194)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:194>).
- [BuildPreview (line 212)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:212>).
- [PreviewMaterial (line 269)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:269>).
- [EnsurePreviewLayer (line 288)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:288>).
- [ChildTransform (line 299)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:299>).
- [Child (line 304)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:304>).
- [Text (line 313)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:313>).
- [Button (line 319)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:319>).
- [Stretch (line 329)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:329>).
- [At (line 334)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:334>).
- [Line (line 338)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:338>).
- [Set (line 347)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:347>).
- [EnsureFolder (line 348)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PinkRhythmUIBuilder.cs:348>).

## PlayerCameraChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PlayerCameraChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/PlayerCameraChecks.cs)

**Declared types:** `PlayerCameraChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Validate Player Camera Startup`.

**Entry points and methods:**

- [PlayerCameraChecks (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PlayerCameraChecks.cs:13>).
- [Check (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PlayerCameraChecks.cs:14>).
- [Run (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PlayerCameraChecks.cs:39>).
- [Require (line 56)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/PlayerCameraChecks.cs:56>).

## SaveFadeFrameProbe.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFadeFrameProbe.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/SaveFadeFrameProbe.cs)

**Declared types:** `SaveFadeFrameProbe`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [LateUpdate (line 6)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFadeFrameProbe.cs:6>).

## SaveFileChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/SaveFileChecks.cs)

**Declared types:** `SaveFileChecks`.

**Teaching:** [What is confirmed, what needs a playtest, and known gaps](../Features/30-verification-and-gaps.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [SaveFileChecks (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:30>).
- [Check (line 31)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:31>).
- [Finish (line 67)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:67>).
- [Run (line 76)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:76>).
- [BeginFadeCheck (line 203)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:203>).
- [ObserveFade (line 208)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:208>).
- [EndFadeCheck (line 217)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:217>).
- [Shape (line 225)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:225>).
- [Reject (line 226)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:226>).
- [DisableEncounters (line 227)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:227>).
- [Require (line 230)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:230>).
- [CaptureError (line 231)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:231>).
- [Capture (line 233)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileChecks.cs:233>).

## SaveFileSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/SaveFileSetup.cs)

**Declared types:** `SaveFileSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Save Files/Set Up Save Menus`.

**Entry points and methods:**

- [SaveFileSetup (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:17>).
- [Check (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:18>).
- [Build (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:26>).
- [SetUpScene (line 31)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:31>).
- [SetUpTitle (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:39>).
- [SetUpGame (line 83)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:83>).
- [FitNavigation (line 91)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:91>).
- [Centre (line 129)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:129>).
- [Button (line 134)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:134>).
- [Label (line 143)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:143>).
- [Assign (line 150)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:150>).
- [Assign (line 151)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/SaveFileSetup.cs:151>).

## TerrainBuildCheck.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/TerrainBuildCheck.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/TerrainBuildCheck.cs)

**Declared types:** `TerrainBuildCheck`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Build (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/TerrainBuildCheck.cs:11>).

## WiSeAssetGenerator.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiSeAssetGenerator.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/WiSeAssetGenerator.cs)

**Declared types:** `WiSeAssetGenerator`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Generate Potions & Loot Table`.

**Entry points and methods:**

- [GenerateAll (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiSeAssetGenerator.cs:11>).
- [CreateConsumable (line 53)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiSeAssetGenerator.cs:53>).
- [AddLootEntry (line 76)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiSeAssetGenerator.cs:76>).
- [EnsureFolder (line 85)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiSeAssetGenerator.cs:85>).

## WiseSkillChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/WiseSkillChecks.cs)

**Declared types:** `WiseSkillChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [WiseSkillChecks (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:19>).
- [Finish (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:39>).
- [Require (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:40>).
- [Set (line 41)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:41>).
- [Warp (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:42>).
- [Cast (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:43>).
- [Run (line 52)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:52>).
- [Complete (line 145)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillChecks.cs:145>).

## WiseSkillFeedbackSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillFeedbackSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/WiseSkillFeedbackSetup.cs)

**Declared types:** `WiseSkillFeedbackSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Editor menu:** `WiSe/Battle/Set Up WiSe Skill Feedback`.

**Entry points and methods:**

- [WiseSkillFeedbackSetup (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillFeedbackSetup.cs:14>).
- [Check (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillFeedbackSetup.cs:15>).
- [Build (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillFeedbackSetup.cs:26>).
- [AddDodgeAura (line 52)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSkillFeedbackSetup.cs:52>).

## WiseSwordPosePreview.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordPosePreview.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/WiseSwordPosePreview.cs)

**Declared types:** `WiseSwordPosePreview`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [WiseSwordPosePreview (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordPosePreview.cs:15>).
- [Check (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordPosePreview.cs:16>).
- [Finish (line 36)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordPosePreview.cs:36>).
- [Run (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordPosePreview.cs:37>).

## WiseSwordSetup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/WiseSwordSetup.cs)

**Declared types:** `WiseSwordSetup`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [WiseSwordSetup (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:19>).
- [Bounds (line 31)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:31>).
- [Hero (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:37>).
- [Report (line 38)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:38>).
- [Build (line 72)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:72>).
- [UprightPose (line 123)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:123>).
- [ApplyReadyGrip (line 149)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:149>).
- [SampleAnimator (line 175)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:175>).
- [SaveLiveGrip (line 182)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:182>).
- [SwordMaterial (line 189)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseSwordSetup.cs:189>).

## WiseTreeCutChecks.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseTreeCutChecks.cs>) · [Copy](../Scripts/Assets/Scripts/Editor/WiseTreeCutChecks.cs)

**Declared types:** `WiseTreeCutChecks`.

**Role:** editor tooling. Use the MenuItem/entry points below to distinguish checking from asset setup.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [WiseTreeCutChecks (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseTreeCutChecks.cs:18>).
- [Check (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseTreeCutChecks.cs:19>).
- [Finish (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseTreeCutChecks.cs:39>).
- [Require (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseTreeCutChecks.cs:40>).
- [Cut (line 41)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseTreeCutChecks.cs:41>).
- [Run (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/Editor/WiseTreeCutChecks.cs:42>).
