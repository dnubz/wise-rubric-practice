# Interactable scripts

[Script index](README.md) · [Guide home](../README.md)

## Chest.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs>) · [Copy](../Scripts/Assets/Scripts/Interactable/Chest.cs)

**Declared types:** `Chest`.

**Teaching:** [Druid: jumping, slow falling, and the pool cliff](../Features/08-druid-gliding.md), [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [RequireDruidLanding (line 66)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:66>).
- [RequirePlatformLanding (line 67)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:67>).
- [CanInteract (line 69)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:69>).
- [InteractionDistance (line 75)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:75>).
- [OnRequiredPlatform (line 84)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:84>).
- [ConfigureLootSeed (line 100)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:100>).
- [ConfigureWorldLoot (line 101)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:101>).
- [RestoreOpenedState (line 107)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:107>).
- [Awake (line 114)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:114>).
- [Start (line 120)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:120>).
- [Update (line 125)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:125>).
- [CheckPlayerDistance (line 137)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:137>).
- [GetPlayerTransform (line 143)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:143>).
- [IsFKeyPressed (line 154)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:154>).
- [OpenChest (line 170)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:170>).
- [AnimateLidOpen (line 224)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:224>).
- [ShowRewardFeedback (line 242)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:242>).
- [SetPromptVisible (line 250)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:250>).
- [SetupPromptUI (line 255)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:255>).
- [OnDrawGizmosSelected (line 263)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs:263>).

## LootEntry.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/LootEntry.cs>) · [Copy](../Scripts/Assets/Scripts/Interactable/LootEntry.cs)

**Declared types:** `LootEntry`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [LootEntry (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/LootEntry.cs:17>).
- [LootEntry (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/LootEntry.cs:19>).

## LootTable.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/LootTable.cs>) · [Copy](../Scripts/Assets/Scripts/Interactable/LootTable.cs)

**Declared types:** `LootTable`.

**Teaching:** [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [RollEntry (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/LootTable.cs:17>).
- [RollEntry (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/LootTable.cs:19>).

## WorldInteractionPrompt.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/WorldInteractionPrompt.cs>) · [Copy](../Scripts/Assets/Scripts/Interactable/WorldInteractionPrompt.cs)

**Declared types:** `WorldInteractionPrompt`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Create (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/WorldInteractionPrompt.cs:19>).
- [SetTarget (line 29)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/WorldInteractionPrompt.cs:29>).
- [Show (line 31)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/WorldInteractionPrompt.cs:31>).
- [Reward (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/WorldInteractionPrompt.cs:39>).
- [LateUpdate (line 45)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/WorldInteractionPrompt.cs:45>).
- [RefreshPosition (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/WorldInteractionPrompt.cs:46>).
