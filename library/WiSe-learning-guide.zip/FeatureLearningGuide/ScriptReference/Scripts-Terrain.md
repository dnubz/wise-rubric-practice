# Terrain scripts

[Script index](README.md) · [Guide home](../README.md)

## BlendedChunkTerrain.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BlendedChunkTerrain.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/BlendedChunkTerrain.cs)

**Declared types:** `BlendedChunkTerrain`.

**Teaching:** [WFC, weighted entropy, seeded generation, and shoreline rules](../Features/13-overworld-wfc.md), [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [BlendedChunkTerrain (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BlendedChunkTerrain.cs:13>).
- [Paint (line 64)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BlendedChunkTerrain.cs:64>).
- [Dispose (line 135)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BlendedChunkTerrain.cs:135>).

## BuildingSpawner.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/BuildingSpawner.cs)

**Declared types:** `BuildingSpawner`, `BuildingEntry`.

**Teaching:** [Infinite chunks, resources, buildings, NPCs, and decorations](../Features/14-streaming-and-content.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Range (line 59)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:59>).
- [Range (line 62)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:62>).
- [TrySpawnBuilding (line 92)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:92>).
- [IsDungeon (line 108)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:108>).
- [TryEnsureDungeon (line 110)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:110>).
- [SpawnDungeon (line 119)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:119>).
- [SpawnBuilding (line 129)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:129>).
- [Vector3 (line 164)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:164>).
- [HasEntranceGround (line 209)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:209>).
- [HasBlockingObject (line 218)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:218>).
- [TrySpawnDungeon (line 235)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:235>).
- [SpawnHealingSpotNearBuilding (line 240)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:240>).
- [PickBuildingByWeight (line 327)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:327>).
- [ClearOverlappingResources (line 351)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:351>).
- [OnDrawGizmosSelected (line 378)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BuildingSpawner.cs:378>).

## ChunkSpawnUtility.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ChunkSpawnUtility.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/ChunkSpawnUtility.cs)

**Declared types:** `ChunkSpawnUtility`.

**Teaching:** [Infinite chunks, resources, buildings, NPCs, and decorations](../Features/14-streaming-and-content.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [IsOwnedObstacle (line 8)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ChunkSpawnUtility.cs:8>).
- [GetOwnedTerrain (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ChunkSpawnUtility.cs:15>).
- [Contains (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ChunkSpawnUtility.cs:37>).
- [TryGetGround (line 48)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ChunkSpawnUtility.cs:48>).
- [HasGroundAcross (line 85)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ChunkSpawnUtility.cs:85>).
- [TryGetVisualBounds (line 106)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ChunkSpawnUtility.cs:106>).

## DungeonEntrance.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/DungeonEntrance.cs)

**Declared types:** `DungeonEntrance`.

**Teaching:** [Dungeon entry, room doors, keys, treasure, and breakables](../Features/17-dungeon-travel-and-rooms.md).

**Direct saved-scene attachment:** DungeonScene.

**Entry points and methods:**

- [Awake (line 45)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:45>).
- [Start (line 50)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:50>).
- [OnDisable (line 55)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:55>).
- [OnDestroy (line 57)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:57>).
- [SetTargetScene (line 63)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:63>).
- [Update (line 73)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:73>).
- [CheckPlayerDistance (line 87)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:87>).
- [GetPlayerTransform (line 95)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:95>).
- [IsFKeyPressed (line 106)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:106>).
- [SetPromptVisible (line 119)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:119>).
- [TransitionToScene (line 124)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:124>).
- [SetupPromptUI (line 142)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:142>).
- [OnDrawGizmosSelected (line 152)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonEntrance.cs:152>).

## DungeonSpawner.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/DungeonSpawner.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/DungeonSpawner.cs)

**Declared types:** `DungeonSpawner`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

## GeneratedResourceMarker.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/GeneratedResourceMarker.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/GeneratedResourceMarker.cs)

**Declared types:** `GeneratedResourceMarker`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

## HealingSpot.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/HealingSpot.cs)

**Declared types:** `HealingSpot`.

**Teaching:** [Infinite chunks, resources, buildings, NPCs, and decorations](../Features/14-streaming-and-content.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Awake (line 48)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:48>).
- [Start (line 88)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:88>).
- [Update (line 93)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:93>).
- [CheckPlayerDistance (line 98)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:98>).
- [Vector2 (line 108)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:108>).
- [Vector2 (line 109)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:109>).
- [OnTriggerStay (line 130)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:130>).
- [OnTriggerExit (line 142)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:142>).
- [TryHealParty (line 154)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:154>).
- [TestDamageParty (line 216)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:216>).
- [TestTriggerHeal (line 232)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:232>).
- [GetActivePlayerTransform (line 237)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:237>).
- [GetPlayerTransform (line 251)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:251>).
- [SetupPromptUI (line 265)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:265>).
- [LateUpdate (line 300)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:300>).
- [ShowMessage (line 309)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:309>).
- [AnimateMessage (line 323)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:323>).
- [SetPromptVisible (line 352)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:352>).
- [OnDrawGizmosSelected (line 360)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/HealingSpot.cs:360>).

## NPCSpawner.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/NPCSpawner.cs)

**Declared types:** `NPCSpawner`.

**Teaching:** [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md), [Infinite chunks, resources, buildings, NPCs, and decorations](../Features/14-streaming-and-content.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Range (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:11>).
- [Min (line 12)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:12>).
- [Range (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:13>).
- [Min (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:14>).
- [Min (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:15>).
- [Min (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:22>).
- [Min (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:24>).
- [TrySpawnNPCs (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:27>).
- [ChooseNPCPrefab (line 77)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:77>).
- [FindSpawnPosition (line 95)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:95>).
- [AlignVisualBottomToGround (line 147)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs:147>).

## OverworldDecorationSpawner.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldDecorationSpawner.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/OverworldDecorationSpawner.cs)

**Declared types:** `OverworldDecorationSpawner`.

**Teaching:** [Infinite chunks, resources, buildings, NPCs, and decorations](../Features/14-streaming-and-content.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Range (line 8)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldDecorationSpawner.cs:8>).
- [Min (line 9)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldDecorationSpawner.cs:9>).
- [SpawnChunk (line 12)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldDecorationSpawner.cs:12>).
- [Vector2Int (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldDecorationSpawner.cs:22>).
- [Range (line 84)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldDecorationSpawner.cs:84>).

## OverworldObstacleSpawner.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs)

**Declared types:** `OverworldObstacleSpawner`.

**Teaching:** [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [UseSeed (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs:13>).
- [GetOpenedChests (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs:18>).
- [RestoreOpenedChests (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs:24>).
- [IsReserved (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs:26>).
- [SpawnChunk (line 33)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs:33>).
- [Vector3 (line 50)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs:50>).
- [Range (line 79)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs:79>).

## OverworldPlatformObstacle.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldPlatformObstacle.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/OverworldPlatformObstacle.cs)

**Declared types:** `OverworldPlatformObstacle`.

**Teaching:** [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [OnDestroy (line 9)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldPlatformObstacle.cs:9>).
- [Reserves (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldPlatformObstacle.cs:20>).
- [Configure (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldPlatformObstacle.cs:26>).

## PoolBoatContent.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolBoatContent.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/PoolBoatContent.cs)

**Declared types:** `PoolBoatContent`.

**Teaching:** [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md), [What is confirmed, what needs a playtest, and known gaps](../Features/30-verification-and-gaps.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [GetOpenedChests (line 9)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolBoatContent.cs:9>).
- [RestoreOpenedChests (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolBoatContent.cs:15>).
- [PoolBoatContent (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolBoatContent.cs:17>).
- [Create (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolBoatContent.cs:19>).

## PoolGlideCliff.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolGlideCliff.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/PoolGlideCliff.cs)

**Declared types:** `PoolGlideCliff`.

**Teaching:** [Druid: jumping, slow falling, and the pool cliff](../Features/08-druid-gliding.md), [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Place (line 10)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolGlideCliff.cs:10>).
- [Supports (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolGlideCliff.cs:14>).

## ResourceSpawner.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ResourceSpawner.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/ResourceSpawner.cs)

**Declared types:** `ResourceSpawner`.

**Teaching:** [Infinite chunks, resources, buildings, NPCs, and decorations](../Features/14-streaming-and-content.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Spawn (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ResourceSpawner.cs:17>).
- [SpawnGrass (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ResourceSpawner.cs:26>).
- [SpawnSand (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ResourceSpawner.cs:42>).
- [GetRandom (line 53)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ResourceSpawner.cs:53>).
- [SpawnObject (line 61)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/ResourceSpawner.cs:61>).

## SpriteItemBobber.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/SpriteItemBobber.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/SpriteItemBobber.cs)

**Declared types:** `SpriteItemBobber`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Initialize (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/SpriteItemBobber.cs:13>).
- [Initialize (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/SpriteItemBobber.cs:19>).
- [Update (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/SpriteItemBobber.cs:30>).

## TreeCuttable.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/TreeCuttable.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/TreeCuttable.cs)

**Declared types:** `TreeCuttable`, `LootEntry`.

**Teaching:** [WiSe: cutting trees and cactus, and breaking decorations](../Features/06-wise-exploration.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Cut (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/TreeCuttable.cs:21>).
- [SpawnLoot (line 31)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/TreeCuttable.cs:31>).
- [SpawnItem (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/TreeCuttable.cs:46>).
- [Vector3 (line 56)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/TreeCuttable.cs:56>).

## WaterSurfaceBuilder.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WaterSurfaceBuilder.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/WaterSurfaceBuilder.cs)

**Declared types:** `WaterSurfaceBuilder`.

**Teaching:** [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [WaterSurfaceBuilder (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WaterSurfaceBuilder.cs:13>).
- [Create (line 36)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WaterSurfaceBuilder.cs:36>).
- [Dispose (line 53)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WaterSurfaceBuilder.cs:53>).

## WFCTile.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCTile.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/WFCTile.cs)

**Declared types:** `WFCTile`.

**Teaching:** [WFC, weighted entropy, seeded generation, and shoreline rules](../Features/13-overworld-wfc.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

## WFCWorldManager.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/WFCWorldManager.cs)

**Declared types:** `WFCWorldManager`.

**Teaching:** [WFC, weighted entropy, seeded generation, and shoreline rules](../Features/13-overworld-wfc.md), [Infinite chunks, resources, buildings, NPCs, and decorations](../Features/14-streaming-and-content.md), [5×5 pools, swimming, obstacle chests, and the boat mismatch](../Features/15-water-and-obstacles.md), [Git, GitHub, and explaining optimization](../Features/00-git-and-performance.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Range (line 29)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:29>).
- [Min (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:32>).
- [Min (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:40>).
- [Range (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:46>).
- [Min (line 47)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:47>).
- [Range (line 48)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:48>).
- [Min (line 49)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:49>).
- [CaptureLayout (line 63)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:63>).
- [RestoreSavedWorld (line 70)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:70>).
- [GetOpenedPoolChests (line 91)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:91>).
- [Start (line 112)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:112>).
- [Awake (line 128)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:128>).
- [OnEnable (line 137)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:137>).
- [OnDisable (line 146)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:146>).
- [OnDestroy (line 151)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:151>).
- [GetTerrainAt (line 163)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:163>).
- [GetCellTerrain (line 165)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:165>).
- [TryEnsureDungeonNearPlayer (line 169)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:169>).
- [TryGetWaterSurface (line 193)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:193>).
- [GetTerrainAt (line 196)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:196>).
- [GetWaterBedDepth (line 199)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:199>).
- [TryGetPoolOrigin (line 208)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:208>).
- [TryGetPoolBounds (line 220)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:220>).
- [GetTerrainBlend (line 237)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:237>).
- [AddCellWeight (line 277)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:277>).
- [GetCellTerrain (line 284)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:284>).
- [LateUpdate (line 303)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:303>).
- [SetActiveCharacter (line 313)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:313>).
- [RefreshWorldAroundPlayer (line 319)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:319>).
- [GetChunk (line 333)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:333>).
- [UpdateWorld (line 343)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:343>).
- [GenerateChunk (line 400)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:400>).
- [GameObject (line 411)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:411>).
- [ChunkSeed (line 506)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:506>).
- [unchecked (line 508)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:508>).
- [CreateCollapsedChunk (line 511)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:511>).
- [PickTerrain (line 572)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:572>).
- [TerrainWeights (line 590)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:590>).
- [BiomeWeight (line 603)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:603>).
- [CountOptions (line 609)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:609>).
- [FindLowest (line 616)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:616>).
- [Propagate (line 649)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs:649>).

## WorldItem.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WorldItem.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/WorldItem.cs)

**Declared types:** `WorldItem`.

**Teaching:** [WiSe: cutting trees and cactus, and breaking decorations](../Features/06-wise-exploration.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [SetItem (line 7)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WorldItem.cs:7>).
- [OnTriggerEnter (line 12)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WorldItem.cs:12>).

## WorldRandom.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WorldRandom.cs>) · [Copy](../Scripts/Assets/Scripts/Terrain/WorldRandom.cs)

**Declared types:** `WorldRandom`.

**Teaching:** [WFC, weighted entropy, seeded generation, and shoreline rules](../Features/13-overworld-wfc.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [AtPosition (line 7)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WorldRandom.cs:7>).
- [Seed (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WorldRandom.cs:14>).
