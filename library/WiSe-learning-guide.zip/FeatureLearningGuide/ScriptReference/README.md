# Script reference

[Guide home](../README.md)

All scripts in Assets/Scripts, both Assets/Events channels, and the generated InputSystem_Actions wrapper are included. Imported vendor/sample/package code is outside this gameplay index.

**Project** links open the original current file. **Copy** links open the exact study snapshot. Method lines are navigation aids, not a claim that every method was dynamically tested.

| Area | Scripts | Read |
| --- | --- | --- |
| Events | 2 | [Open](Events.md) |
| InputSystem | 1 | [Open](InputSystem.md) |
| Audio | 6 | [Open](Scripts-Audio.md) |
| Battle | 28 | [Open](Scripts-Battle.md) |
| Camera | 1 | [Open](Scripts-Camera.md) |
| Character | 5 | [Open](Scripts-Character.md) |
| CharacterInput | 2 | [Open](Scripts-CharacterInput.md) |
| Dungeon | 19 | [Open](Scripts-Dungeon.md) |
| Editor | 76 | [Open](Scripts-Editor.md) |
| Highlight | 1 | [Open](Scripts-Highlight.md) |
| Interactable | 4 | [Open](Scripts-Interactable.md) |
| Inventory | 9 | [Open](Scripts-Inventory.md) |
| NPC | 6 | [Open](Scripts-NPC.md) |
| Save | 5 | [Open](Scripts-Save.md) |
| Scene | 1 | [Open](Scripts-Scene.md) |
| Shop | 4 | [Open](Scripts-Shop.md) |
| Terrain | 21 | [Open](Scripts-Terrain.md) |
| UI | 1 | [Open](Scripts-UI.md) |
| UI / InGame | 27 | [Open](Scripts-UI-InGame.md) |
| UI / MainMenu | 2 | [Open](Scripts-UI-MainMenu.md) |
| UI / MainMenu / Exit | 1 | [Open](Scripts-UI-MainMenu-Exit.md) |
| UI / MainMenu / Settings | 4 | [Open](Scripts-UI-MainMenu-Settings.md) |
