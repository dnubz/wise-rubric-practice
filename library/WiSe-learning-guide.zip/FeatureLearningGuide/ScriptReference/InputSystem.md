# InputSystem scripts

[Script index](README.md) · [Guide home](../README.md)

## InputSystem_Actions.cs

[Project](<C:/Users/Ezell/WiSe/Assets/InputSystem/InputSystem_Actions.cs>) · [Copy](../Scripts/Assets/InputSystem/InputSystem_Actions.cs)

**Declared types:** `is`, `Example`, `PlayerActions`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.
