# Scene scripts

[Script index](README.md) · [Guide home](../README.md)

## SceneSwitch.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Scene/SceneSwitch.cs>) · [Copy](../Scripts/Assets/Scripts/Scene/SceneSwitch.cs)

**Declared types:** `SceneSwitcher`.

**Teaching:** [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md).

**Direct saved-scene attachment:** TitleScene.

**Entry points and methods:**

- [SwitchScene (line 12)](<C:/Users/Ezell/WiSe/Assets/Scripts/Scene/SceneSwitch.cs:12>).
- [FadeAndSwitch (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Scene/SceneSwitch.cs:18>).
