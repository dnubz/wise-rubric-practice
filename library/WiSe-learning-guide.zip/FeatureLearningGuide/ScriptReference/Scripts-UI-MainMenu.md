# UI / MainMenu scripts

[Script index](README.md) · [Guide home](../README.md)

## ContinueSaveUI.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs>) · [Copy](../Scripts/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs)

**Declared types:** `ContinueSaveUI`.

**Teaching:** [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md), [Three binary save slots and restoring a playthrough](../Features/04-save-files.md).

**Direct saved-scene attachment:** TitleScene.

**Entry points and methods:**

- [Awake (line 10)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs:10>).
- [OnEnable (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs:11>).
- [OnDisable (line 15)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs:15>).
- [Refresh (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs:16>).
- [Continue (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs:21>).
- [LoadFailed (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs:27>).

## SaveSlotUI.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs>) · [Copy](../Scripts/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs)

**Declared types:** `SaveSlotUI`, `Slot`.

**Teaching:** [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md), [Three binary save slots and restoring a playthrough](../Features/04-save-files.md).

**Direct saved-scene attachment:** TitleScene.

**Entry points and methods:**

- [Awake (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:21>).
- [OnEnable (line 35)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:35>).
- [OnDisable (line 36)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:36>).
- [Refresh (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:37>).
- [FormatPlaytime (line 50)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:50>).
- [SelectSlot (line 55)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:55>).
- [LoadFailed (line 64)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:64>).
- [RequestDelete (line 65)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:65>).
- [ConfirmDelete (line 72)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:72>).
- [CancelDelete (line 78)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:78>).
- [OnPlayButtonPressed (line 87)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:87>).
- [PlayParticleAndOpenRoutine (line 92)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:92>).
- [OpenSaveSlots (line 108)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:108>).
- [BackToMainMenu (line 116)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs:116>).
