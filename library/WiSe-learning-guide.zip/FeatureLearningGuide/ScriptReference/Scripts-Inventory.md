# Inventory scripts

[Script index](README.md) · [Guide home](../README.md)

## Consumable.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Consumable.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/Consumable.cs)

**Declared types:** `Consumable`.

**Teaching:** [OOP, ScriptableObjects, and event channels](../Features/01-architecture.md), [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Use (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Consumable.cs:28>).
- [Use (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Consumable.cs:37>).

## Equipment.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Equipment.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/Equipment.cs)

**Declared types:** `Equipment`.

**Teaching:** [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Use (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Equipment.cs:23>).

## Inventory.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Inventory.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/Inventory.cs)

**Declared types:** `Inventory`.

**Teaching:** [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Awake (line 12)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Inventory.cs:12>).
- [AddItem (line 24)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Inventory.cs:24>).
- [RemoveItem (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Inventory.cs:30>).
- [RemoveAll (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Inventory.cs:46>).
- [GetItemCount (line 57)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Inventory.cs:57>).

## InventorySlot.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/InventorySlot.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/InventorySlot.cs)

**Declared types:** `InventorySlot`.

**Teaching:** [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [InventorySlot (line 10)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/InventorySlot.cs:10>).

## InventoryTest.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/InventoryTest.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/InventoryTest.cs)

**Declared types:** `InventoryTest`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [AddTestPotions (line 9)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/InventoryTest.cs:9>).

## Item.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Item.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/Item.cs)

**Declared types:** `Item`.

**Teaching:** [OOP, ScriptableObjects, and event channels](../Features/01-architecture.md), [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Use (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Item.cs:17>).

## PlayerInventory.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/PlayerInventory.cs)

**Declared types:** `PlayerInventory`.

**Teaching:** [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md), [Item/equipment shops and resource merchants](../Features/12-shops.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Awake (line 65)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:65>).
- [OnApplicationQuit (line 82)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:82>).
- [OnDestroy (line 87)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:87>).
- [AddGold (line 98)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:98>).
- [SpendGold (line 110)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:110>).
- [CanAfford (line 127)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:127>).
- [SetGold (line 130)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:130>).
- [AddItem (line 140)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:140>).
- [AddItem (line 168)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:168>).
- [UseConsumable (line 174)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:174>).
- [CountOf (line 192)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:192>).
- [HasItem (line 205)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:205>).
- [ClearItems (line 207)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:207>).
- [DebugPrint (line 212)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/PlayerInventory.cs:212>).

## ResourceItem.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/ResourceItem.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/ResourceItem.cs)

**Declared types:** `ResourceItem`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

## ResourcePickup.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/ResourcePickup.cs>) · [Copy](../Scripts/Assets/Scripts/Inventory/ResourcePickup.cs)

**Declared types:** `ResourcePickup`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [OnTriggerEnter (line 7)](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/ResourcePickup.cs:7>).
