# NPC scripts

[Script index](README.md) · [Guide home](../README.md)

## InteractableNPC.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs>) · [Copy](../Scripts/Assets/Scripts/NPC/InteractableNPC.cs)

**Declared types:** `InteractableNPC`.

**Teaching:** [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md), [Item/equipment shops and resource merchants](../Features/12-shops.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [OnPlayerApproached (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs:20>).
- [HandleInput (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs:27>).
- [OnSentenceFinished (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs:32>).
- [OnFKeyPressedAfterSentence (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs:37>).
- [TriggerInteraction (line 54)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs:54>).
- [OnPlayerExited (line 82)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs:82>).
- [OnDisable (line 87)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs:87>).

## MinigameNPC.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs>) · [Copy](../Scripts/Assets/Scripts/NPC/MinigameNPC.cs)

**Declared types:** `MinigameNPC`, `MinigameKind`.

**Teaching:** [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md), [Berdly chemistry battle: answers, timer, attack, and defend](../Features/25-berdly-minigame.md), [Pink rhythm: beatmap parsing, tap/hold judgements, and score](../Features/27-rhythm-game.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Awake (line 33)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:33>).
- [OnEnable (line 35)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:35>).
- [Start (line 37)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:37>).
- [DistanceToPlayerSquared (line 43)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:43>).
- [OnPlayerApproached (line 50)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:50>).
- [HandleInput (line 57)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:57>).
- [OnSentenceFinished (line 63)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:63>).
- [OnFKeyPressedAfterSentence (line 68)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:68>).
- [ShowChallengeModal (line 84)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:84>).
- [StartDialogue (line 94)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:94>).
- [OnAcceptChallengeClicked (line 100)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:100>).
- [OnDeclineChallengeClicked (line 112)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:112>).
- [CancelChallengePrompt (line 120)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:120>).
- [OnDisable (line 126)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:126>).
- [OnPlayerExited (line 135)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs:135>).

## NormalNPC.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs>) · [Copy](../Scripts/Assets/Scripts/NPC/NormalNPC.cs)

**Declared types:** `NormalNPC`.

**Teaching:** [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [OnPlayerApproached (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:14>).
- [HandleInput (line 21)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:21>).
- [OnSentenceFinished (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:26>).
- [OnFKeyPressedAfterSentence (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:46>).
- [AutoAdvanceRoutine (line 74)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:74>).
- [AutoCloseRoutine (line 81)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:81>).
- [OnPlayerExited (line 96)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:96>).
- [OnDisable (line 107)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs:107>).

## NPCAmbientLight.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCAmbientLight.cs>) · [Copy](../Scripts/Assets/Scripts/NPC/NPCAmbientLight.cs)

**Declared types:** `NPCAmbientLight`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Start (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCAmbientLight.cs:23>).
- [LateUpdate (line 42)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCAmbientLight.cs:42>).

## NPCBase.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs>) · [Copy](../Scripts/Assets/Scripts/NPC/NPCBase.cs)

**Declared types:** `NPCBase`.

**Teaching:** [OOP, ScriptableObjects, and event channels](../Features/01-architecture.md), [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [TextArea (line 9)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:9>).
- [Range (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:17>).
- [Awake (line 38)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:38>).
- [Start (line 54)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:54>).
- [Update (line 65)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:65>).
- [FaceTarget (line 87)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:87>).
- [SetModelRotationOffset (line 98)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:98>).
- [ReturnToInitialRotation (line 103)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:103>).
- [CheckPlayerProximity (line 111)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:111>).
- [GetPlayerTransform (line 143)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:143>).
- [PlayGreeting (line 153)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:153>).
- [HandleInput (line 168)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:168>).
- [OnFKeyPressed (line 174)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:174>).
- [OnFKeyPressedAfterSentence (line 187)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:187>).
- [StartDialogue (line 192)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:192>).
- [DisplayLine (line 203)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:203>).
- [SetDialogue (line 220)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:220>).
- [RefreshSpeechBubble (line 225)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:225>).
- [TypewriterRoutine (line 230)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:230>).
- [FinishTypingCurrentSentence (line 253)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:253>).
- [OnSentenceFinished (line 272)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:272>).
- [NextSentence (line 277)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:277>).
- [EndDialogue (line 290)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:290>).
- [OnPlayerApproached (line 307)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:307>).
- [OnPlayerExited (line 309)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:309>).
- [OnDisable (line 314)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:314>).
- [OnDialogueCompleted (line 321)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:321>).
- [IsFKeyPressed (line 323)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:323>).
- [OnDrawGizmosSelected (line 336)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:336>).

## NPCSpeechBubble.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs>) · [Copy](../Scripts/Assets/Scripts/NPC/NPCSpeechBubble.cs)

**Declared types:** `NPCSpeechBubble`.

**Teaching:** [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Min (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:16>).
- [Min (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:17>).
- [Awake (line 23)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:23>).
- [Initialize (line 35)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:35>).
- [LateUpdate (line 59)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:59>).
- [RefreshPosition (line 64)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:64>).
- [ApplyWorldScale (line 92)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:92>).
- [Show (line 119)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:119>).
- [Hide (line 128)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:128>).
- [SetText (line 136)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:136>).
- [SetInteractPromptVisible (line 145)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:145>).
- [PrepareTyping (line 153)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:153>).
- [ShowCharacters (line 161)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:161>).
- [IsVisible (line 166)](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs:166>).
