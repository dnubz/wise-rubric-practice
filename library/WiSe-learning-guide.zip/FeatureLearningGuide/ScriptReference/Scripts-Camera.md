# Camera scripts

[Script index](README.md) · [Guide home](../README.md)

## CameraController.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs>) · [Copy](../Scripts/Assets/Scripts/Camera/CameraController.cs)

**Declared types:** `CameraController`.

**Teaching:** [Exploration camera, zoom, overworld map, and dungeon reveal](../Features/18-cameras-and-maps.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Range (line 25)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:25>).
- [OnEnable (line 51)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:51>).
- [OnDisable (line 73)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:73>).
- [SetTarget (line 90)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:90>).
- [SnapToTarget (line 96)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:96>).
- [CacheViews (line 101)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:101>).
- [SetDungeonView (line 118)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:118>).
- [Start (line 145)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:145>).
- [LateUpdate (line 159)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:159>).
- [OnZoom (line 190)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:190>).
- [SetMinimapScrollFocus (line 202)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:202>).
- [ChangeCamera (line 207)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:207>).
- [SetCamera (line 239)](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs:239>).
