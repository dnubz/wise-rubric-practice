# Events scripts

[Script index](README.md) · [Guide home](../README.md)

## CharacterHudEventChannel.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Events/CharacterHudEventChannel.cs>) · [Copy](../Scripts/Assets/Events/CharacterHudEventChannel.cs)

**Declared types:** `CharacterHudEventChannel`.

**Teaching:** [OOP, ScriptableObjects, and event channels](../Features/01-architecture.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [RaiseCharacterSelected (line 10)](<C:/Users/Ezell/WiSe/Assets/Events/CharacterHudEventChannel.cs:10>).
- [RaiseCharacterStatsChanged (line 15)](<C:/Users/Ezell/WiSe/Assets/Events/CharacterHudEventChannel.cs:15>).

## IntEventChannel.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Events/IntEventChannel.cs>) · [Copy](../Scripts/Assets/Events/IntEventChannel.cs)

**Declared types:** `IntEventChannel`.

**Teaching:** [OOP, ScriptableObjects, and event channels](../Features/01-architecture.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [RaiseEvent (line 12)](<C:/Users/Ezell/WiSe/Assets/Events/IntEventChannel.cs:12>).
