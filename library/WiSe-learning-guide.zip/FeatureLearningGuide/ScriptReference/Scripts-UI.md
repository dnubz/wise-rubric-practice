# UI scripts

[Script index](README.md) · [Guide home](../README.md)

## SceneTravelFade.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs>) · [Copy](../Scripts/Assets/Scripts/UI/SceneTravelFade.cs)

**Declared types:** `SceneTravelFade`.

**Teaching:** [Dungeon entry, room doors, keys, treasure, and breakables](../Features/17-dungeon-travel-and-rooms.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [ResetStatics (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:18>).
- [Ensure (line 20)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:20>).
- [CoverArrival (line 35)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:35>).
- [FadeOut (line 41)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:41>).
- [FadeIn (line 47)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:47>).
- [LoadGameScene (line 55)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:55>).
- [Load (line 67)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:67>).
- [OnDisable (line 87)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:87>).
- [OnDestroy (line 92)](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/SceneTravelFade.cs:92>).
