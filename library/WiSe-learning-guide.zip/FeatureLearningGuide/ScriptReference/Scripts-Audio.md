# Audio scripts

[Script index](README.md) · [Guide home](../README.md)

## AudioManager.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/AudioManager.cs>) · [Copy](../Scripts/Assets/Scripts/Audio/AudioManager.cs)

**Declared types:** `AudioManager`.

**Role:** supporting code in this area. Trace its owner/controller and callers alongside the related feature chapters.

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Start (line 5)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/AudioManager.cs:5>).
- [Update (line 9)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/AudioManager.cs:9>).

## CharacterSurfaceAudio.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/CharacterSurfaceAudio.cs>) · [Copy](../Scripts/Assets/Scripts/Audio/CharacterSurfaceAudio.cs)

**Declared types:** `CharacterSurfaceAudio`.

**Teaching:** [Audio routing, footsteps, particles, highlights, and UI feedback](../Features/29-audio-and-visual-feedback.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [Awake (line 14)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/CharacterSurfaceAudio.cs:14>).
- [OnEnable (line 27)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/CharacterSurfaceAudio.cs:27>).
- [OnDisable (line 28)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/CharacterSurfaceAudio.cs:28>).
- [LateUpdate (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/CharacterSurfaceAudio.cs:30>).
- [PlaySplash (line 63)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/CharacterSurfaceAudio.cs:63>).
- [Play (line 68)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/CharacterSurfaceAudio.cs:68>).

## GameAudio.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs>) · [Copy](../Scripts/Assets/Scripts/Audio/GameAudio.cs)

**Declared types:** `GameAudio`.

**Teaching:** [Music, SFX, frame rate, resolution, and fullscreen](../Features/03-settings.md), [Audio routing, footsteps, particles, highlights, and UI feedback](../Features/29-audio-and-visual-feedback.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [ApplySavedVolumes (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:11>).
- [SetMusic (line 16)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:16>).
- [SetSFX (line 17)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:17>).
- [Save (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:18>).
- [Apply (line 22)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:22>).
- [RouteMusic (line 26)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:26>).
- [RouteSFX (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:32>).
- [RouteUnassignedSources (line 40)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:40>).
- [PlaySFXAtPoint (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs:46>).

## GameAudioBootstrap.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudioBootstrap.cs>) · [Copy](../Scripts/Assets/Scripts/Audio/GameAudioBootstrap.cs)

**Declared types:** `GameAudioBootstrap`.

**Teaching:** [Music, SFX, frame rate, resolution, and fullscreen](../Features/03-settings.md), [Audio routing, footsteps, particles, highlights, and UI feedback](../Features/29-audio-and-visual-feedback.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [Create (line 11)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudioBootstrap.cs:11>).
- [Awake (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudioBootstrap.cs:19>).
- [OnSceneLoaded (line 33)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudioBootstrap.cs:33>).
- [Update (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudioBootstrap.cs:39>).
- [OnDestroy (line 46)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudioBootstrap.cs:46>).

## OverworldMusicController.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs>) · [Copy](../Scripts/Assets/Scripts/Audio/OverworldMusicController.cs)

**Declared types:** `OverworldMusicController`.

**Teaching:** [Audio routing, footsteps, particles, highlights, and UI feedback](../Features/29-audio-and-visual-feedback.md).

**Direct saved-scene attachment:** GameScene.

**Entry points and methods:**

- [ResetStatics (line 18)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:18>).
- [Awake (line 19)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:19>).
- [Register (line 30)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:30>).
- [Unregister (line 31)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:31>).
- [Owns (line 32)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:32>).
- [BeginBerdlyBattle (line 33)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:33>).
- [EndBerdlyBattle (line 34)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:34>).
- [SilenceForRhythm (line 35)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:35>).
- [ResumeAfterRhythm (line 36)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:36>).
- [LateUpdate (line 38)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:38>).
- [Tick (line 39)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:39>).
- [OnDestroy (line 75)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs:75>).

## SurfaceAudioSettings.cs

[Project](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/SurfaceAudioSettings.cs>) · [Copy](../Scripts/Assets/Scripts/Audio/SurfaceAudioSettings.cs)

**Declared types:** `SurfaceAudioSettings`.

**Teaching:** [Audio routing, footsteps, particles, highlights, and UI feedback](../Features/29-audio-and-visual-feedback.md), [What is confirmed, what needs a playtest, and known gaps](../Features/30-verification-and-gaps.md).

**Scene evidence:** no direct component reference in the four main scene YAML files. It may be a data/static type, prefab component, runtime-created component, or editor tool.

**Entry points and methods:**

- [WalkingClip (line 13)](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/SurfaceAudioSettings.cs:13>).
