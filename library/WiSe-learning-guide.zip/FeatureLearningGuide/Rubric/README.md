# Workbook requirement index

[Guide home](../README.md) · [Scoring explanation](../02-workbook-and-scoring.md)

Every feature requirement row is routed to a teaching chapter and its code owner. Requirement labels remain as written in the workbook; they are reference material, not new commands.

- [General](General.md).
- [Main Menu](Main-Menu.md).
- [Settings](Settings.md).
- [Save File](Save-File.md).
- [Characters](Characters.md).
- [NPC](NPC.md).
- [Item](Item.md).
- [Equipment](Equipment.md).
- [Dungeon](Dungeon.md).
- [Shop](Shop.md).
- [Overworld](Overworld.md).
- [Battle](Battle.md).
- [Boss Battle](Boss-Battle.md).
- [Skills](Skills.md).
- [Enemies](Enemies.md).
- [Minigame](Minigame.md).
- [Cheats](Cheats.md).
- [Rythm Game](Rythm-Game.md).
- [IUPAC Algorithm](IUPAC-Algorithm.md).
