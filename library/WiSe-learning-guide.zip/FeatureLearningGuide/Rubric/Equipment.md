# Equipment: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `Equipment`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 6 | Equipment menu | 4 | 0.4 | 0.4 | [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) | [EquipmentUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/EquipmentUI.cs>) |
| 7 | Equip the equipment | 4 | 0.6 | 0.6 | [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) | [CharacterBase.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Character/CharacterBase.cs>) |
| 8 | Show stats difference | 4 | 0.2 | 0.2 | [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) | [EquipmentUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/EquipmentUI.cs>) |
| 9 | Show remove option | 4 | 0.2 | 0.2 | [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) | [EquipmentUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/EquipmentUI.cs>) |
| 10 | All equipments are implemented | 4 | 0.6 | 0.6 | [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) | [Equipment.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Equipment.cs>) |

## Row locators

### Row 6

**Equipment menu**

Read [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) for the behavior, code flow, and demonstration. Source score: `Equipment!E6`. Source maximum/points: `C6` / `F6`.

### Row 7

**Equip the equipment**

Read [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) for the behavior, code flow, and demonstration. Source score: `Equipment!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Show stats difference**

Read [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) for the behavior, code flow, and demonstration. Source score: `Equipment!E8`. Source maximum/points: `C8` / `F8`.

### Row 9

**Show remove option**

Read [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) for the behavior, code flow, and demonstration. Source score: `Equipment!E9`. Source maximum/points: `C9` / `F9`.

### Row 10

**All equipments are implemented**

Read [Two equipment slots, stat differences, and removing gear](../Features/11-equipment.md) for the behavior, code flow, and demonstration. Source score: `Equipment!E10`. Source maximum/points: `C10` / `F10`.
