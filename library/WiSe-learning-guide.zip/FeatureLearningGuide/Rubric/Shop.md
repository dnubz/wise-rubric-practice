# Shop: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `Shop`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 7 | Show every item in the shop | 4 | 0.16 | 0.16 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 8 | Exclude diamond from the shop | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 9 | Show coins | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 10 | Show current selected item's name | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 11 | Show description | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 12 | Show amount | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 13 | Decrease the amount | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 14 | Increase the amount | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 15 | Show coin cost | 4 | 0.0533333 | 0.0533333 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 16 | Buy the item | 4 | 0.16 | 0.16 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 17 | Show error message when player doesn't have enough coin | 0 | 0.0533333 | 0 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 22 | Show every equipment in the shop | 4 | 0.171429 | 0.171429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 23 | Show coins | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 24 | Show current selected equipment's name | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 25 | Show description | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 26 | Show amount | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 27 | Decrease the amount | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 28 | Increase the amount | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 29 | Show coin cost | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 30 | Buy the equipment | 4 | 0.171429 | 0.171429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 31 | Show error message when player doesn't have enough coin | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ShopUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ShopUI.cs>) |
| 36 | Randomize merchant types (wood, rock, cactus, mushroom) | 4 | 0.114286 | 0.114286 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ResourceSellUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ResourceSellUI.cs>) |
| 37 | Show modal | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ResourceSellUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ResourceSellUI.cs>) |
| 38 | Show total coin | 4 | 0.0571429 | 0.0571429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ResourceSellUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ResourceSellUI.cs>) |
| 39 | Sell resources | 4 | 0.171429 | 0.171429 | [Item/equipment shops and resource merchants](../Features/12-shops.md) | [ResourceSellUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Shop/ResourceSellUI.cs>) |

## Row locators

### Row 7

**Show every item in the shop**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Exclude diamond from the shop**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E8`. Source maximum/points: `C8` / `F8`.

### Row 9

**Show coins**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E9`. Source maximum/points: `C9` / `F9`.

### Row 10

**Show current selected item's name**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E10`. Source maximum/points: `C10` / `F10`.

### Row 11

**Show description**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E11`. Source maximum/points: `C11` / `F11`.

### Row 12

**Show amount**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E12`. Source maximum/points: `C12` / `F12`.

### Row 13

**Decrease the amount**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E13`. Source maximum/points: `C13` / `F13`.

### Row 14

**Increase the amount**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E14`. Source maximum/points: `C14` / `F14`.

### Row 15

**Show coin cost**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E15`. Source maximum/points: `C15` / `F15`.

### Row 16

**Buy the item**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E16`. Source maximum/points: `C16` / `F16`.

### Row 17

**Show error message when player doesn't have enough coin**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E17`. Source maximum/points: `C17` / `F17`.

### Row 22

**Show every equipment in the shop**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E22`. Source maximum/points: `C22` / `F22`.

### Row 23

**Show coins**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E23`. Source maximum/points: `C23` / `F23`.

### Row 24

**Show current selected equipment's name**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E24`. Source maximum/points: `C24` / `F24`.

### Row 25

**Show description**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E25`. Source maximum/points: `C25` / `F25`.

### Row 26

**Show amount**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E26`. Source maximum/points: `C26` / `F26`.

### Row 27

**Decrease the amount**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E27`. Source maximum/points: `C27` / `F27`.

### Row 28

**Increase the amount**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E28`. Source maximum/points: `C28` / `F28`.

### Row 29

**Show coin cost**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E29`. Source maximum/points: `C29` / `F29`.

### Row 30

**Buy the equipment**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E30`. Source maximum/points: `C30` / `F30`.

### Row 31

**Show error message when player doesn't have enough coin**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E31`. Source maximum/points: `C31` / `F31`.

### Row 36

**Randomize merchant types (wood, rock, cactus, mushroom)**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E36`. Source maximum/points: `C36` / `F36`.

### Row 37

**Show modal**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E37`. Source maximum/points: `C37` / `F37`.

### Row 38

**Show total coin**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E38`. Source maximum/points: `C38` / `F38`.

### Row 39

**Sell resources**

Read [Item/equipment shops and resource merchants](../Features/12-shops.md) for the behavior, code flow, and demonstration. Source score: `Shop!E39`. Source maximum/points: `C39` / `F39`.
