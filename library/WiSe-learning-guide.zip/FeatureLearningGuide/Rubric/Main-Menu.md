# Main Menu: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `Main Menu`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 7 | Show title | 0 | 0.025 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | Scene / visual / human evidence needed |
| 8 | Play Button | 0 | 0.025 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | [SaveSlotUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs>) |
| 9 | Setting Button | 0 | 0.025 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | [SettingsUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Settings/SettingsUI.cs>) |
| 10 | Exit Button | 0 | 0.025 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | [Exit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Exit/Exit.cs>) |
| 15 | Show every character's model | 0 | 0.0727273 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | Scene / visual / human evidence needed |
| 16 | Every character have different animation | 0 | 0.145455 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | Scene / visual / human evidence needed |
| 17 | Play animation after pressing play game | 0 | 0.290909 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | Scene / visual / human evidence needed |
| 18 | Creativity and design | 0 | 0.290909 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | Scene / visual / human evidence needed |
| 23 | Animation | 0 | 0.0333333 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | Scene / visual / human evidence needed |
| 24 | Music | 0 | 0.0333333 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | [TitleAudio.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Settings/TitleAudio.cs>) |
| 25 | SFX | 0 | 0.0333333 | 0 | [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) | [TitleAudio.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Settings/TitleAudio.cs>) |

## Row locators

### Row 7

**Show title**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Play Button**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E8`. Source maximum/points: `C8` / `F8`.

### Row 9

**Setting Button**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E9`. Source maximum/points: `C9` / `F9`.

### Row 10

**Exit Button**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E10`. Source maximum/points: `C10` / `F10`.

### Row 15

**Show every character's model**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E15`. Source maximum/points: `C15` / `F15`.

### Row 16

**Every character have different animation**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E16`. Source maximum/points: `C16` / `F16`.

### Row 17

**Play animation after pressing play game**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E17`. Source maximum/points: `C17` / `F17`.

### Row 18

**Creativity and design**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E18`. Source maximum/points: `C18` / `F18`.

### Row 23

**Animation**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E23`. Source maximum/points: `C23` / `F23`.

### Row 24

**Music**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E24`. Source maximum/points: `C24` / `F24`.

### Row 25

**SFX**

Read [Title screen, Play, Continue, and Exit](../Features/02-title-menu.md) for the behavior, code flow, and demonstration. Source score: `Main Menu!E25`. Source maximum/points: `C25` / `F25`.
