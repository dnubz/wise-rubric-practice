# Battle: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `Battle`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 7 | Start battle when colliding with enemy/enemy hit | 4 | 0.098 | 0.098 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [EncounterEnemy.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/EncounterEnemy.cs>) |
| 8 | Battle transition | 2 | 0.098 | 0.049 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleSession.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSession.cs>) |
| 9 | Minimum 3 layouts for battle | 1 | 0.196 | 0.049 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleLayout.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleLayout.cs>) |
| 10 | Randomize the layout | 1 | 0.098 | 0.0245 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 15 | Characters | 4 | 0.091 | 0.091 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 16 | Obstacle | 2 | 0.364 | 0.182 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleCover.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleCover.cs>) |
| 17 | Obstacle state | 3 | 0.273 | 0.20475 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleCover.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleCover.cs>) |
| 18 | Enemy randomization | 2 | 0.091 | 0.0455 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 19 | Enemy, obstacle & character transparation | 4 | 0.364 | 0.364 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleAppearance.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleAppearance.cs>) |
| 20 | Damage formula | 4 | 0.091 | 0.091 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 21 | Damage and healing popup | 4 | 0.091 | 0.091 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattlePopup.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattlePopup.cs>) |
| 22 | Victory | 4 | 0.364 | 0.364 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 23 | Game over | 1 | 0.091 | 0.02275 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 28 | Changing character | 2 | 0.155556 | 0.0777778 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 29 | Character's movement range | 2 | 0.311111 | 0.155556 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 30 | Character's movement range reset | 2 | 0.155556 | 0.0777778 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 31 | Character's action point | 2 | 0.311111 | 0.155556 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 32 | Character's basic attack locking their position | 2 | 0.155556 | 0.0777778 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 33 | Character's death | 2 | 0.155556 | 0.0777778 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 34 | Persist skill cooldown | 2 | 0.155556 | 0.0777778 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [CharacterBase.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Character/CharacterBase.cs>) |
| 39 | Enemy's movement range | 0 | 0.35 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 40 | Enemy's movement range reset | 0 | 0.175 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 41 | Enemy's attack range | 0 | 0.35 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleEnemyData.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleEnemyData.cs>) |
| 42 | Fast forward | 0 | 0.175 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 47 | Each character's potrait | 0 | 0.0933333 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleHUD.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleHUD.cs>) |
| 48 | Each character's HP bar | 0 | 0.0933333 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleHUD.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleHUD.cs>) |
| 49 | Each character's SP bar | 0 | 0.0933333 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleHUD.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleHUD.cs>) |
| 50 | Each character's skill icon | 0 | 0.0933333 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleHUD.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleHUD.cs>) |
| 51 | Skill icon cooldown | 0 | 0.0933333 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleHUD.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleHUD.cs>) |
| 52 | Each character's action point | 0 | 0.0933333 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleHUD.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleHUD.cs>) |
| 57 | Enemy's turn UI | 0 | 0.14 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleHUD.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleHUD.cs>) |
| 58 | Enemy's health bar | 0 | 0.14 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleWorldUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleWorldUI.cs>) |
| 63 | Menu Overlay | 0 | 0.07 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleSession.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSession.cs>) |
| 64 | Use item while in the battle | 0 | 0.14 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [InventoryUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/InventoryUI.cs>) |
| 65 | Save and quit | 0 | 0.07 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [GameSave.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/GameSave.cs>) |
| 70 | Player's returning to location where the enemy was first encountered | 0 | 0.21 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleSession.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSession.cs>) |
| 71 | Defeated enemy not appearing again | 0 | 0.21 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleSession.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSession.cs>) |
| 76 | End turns | 0 | 0.0777778 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 77 | Rotate camera | 0 | 0.0777778 | 0 | [Exploration camera, zoom, overworld map, and dungeon reveal](../Features/18-cameras-and-maps.md) | [BattleCamera.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleCamera.cs>) |
| 78 | Move | 0 | 0.0777778 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 79 | Selecting skills | 0 | 0.0777778 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 80 | Confirm skill | 0 | 0.0777778 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 81 | Aiming & Charging (RandaL) | 0 | 0.0777778 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 82 | Rotate camera | 0 | 0.0777778 | 0 | [Exploration camera, zoom, overworld map, and dungeon reveal](../Features/18-cameras-and-maps.md) | [BattleCamera.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleCamera.cs>) |
| 83 | Change character | 0 | 0.0777778 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 84 | Esc to menu | 0 | 0.0777778 | 0 | [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) | [BattleSession.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSession.cs>) |

## Row locators

### Row 7

**Start battle when colliding with enemy/enemy hit**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Battle transition**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E8`. Source maximum/points: `C8` / `F8`.

### Row 9

**Minimum 3 layouts for battle**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E9`. Source maximum/points: `C9` / `F9`.

### Row 10

**Randomize the layout**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E10`. Source maximum/points: `C10` / `F10`.

### Row 15

**Characters**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E15`. Source maximum/points: `C15` / `F15`.

### Row 16

**Obstacle**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E16`. Source maximum/points: `C16` / `F16`.

### Row 17

**Obstacle state**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E17`. Source maximum/points: `C17` / `F17`.

### Row 18

**Enemy randomization**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E18`. Source maximum/points: `C18` / `F18`.

### Row 19

**Enemy, obstacle & character transparation**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E19`. Source maximum/points: `C19` / `F19`.

### Row 20

**Damage formula**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E20`. Source maximum/points: `C20` / `F20`.

### Row 21

**Damage and healing popup**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E21`. Source maximum/points: `C21` / `F21`.

### Row 22

**Victory**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E22`. Source maximum/points: `C22` / `F22`.

### Row 23

**Game over**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E23`. Source maximum/points: `C23` / `F23`.

### Row 28

**Changing character**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E28`. Source maximum/points: `C28` / `F28`.

### Row 29

**Character's movement range**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E29`. Source maximum/points: `C29` / `F29`.

### Row 30

**Character's movement range reset**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E30`. Source maximum/points: `C30` / `F30`.

### Row 31

**Character's action point**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E31`. Source maximum/points: `C31` / `F31`.

### Row 32

**Character's basic attack locking their position**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E32`. Source maximum/points: `C32` / `F32`.

### Row 33

**Character's death**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E33`. Source maximum/points: `C33` / `F33`.

### Row 34

**Persist skill cooldown**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E34`. Source maximum/points: `C34` / `F34`.

### Row 39

**Enemy's movement range**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E39`. Source maximum/points: `C39` / `F39`.

### Row 40

**Enemy's movement range reset**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E40`. Source maximum/points: `C40` / `F40`.

### Row 41

**Enemy's attack range**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E41`. Source maximum/points: `C41` / `F41`.

### Row 42

**Fast forward**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E42`. Source maximum/points: `C42` / `F42`.

### Row 47

**Each character's potrait**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E47`. Source maximum/points: `C47` / `F47`.

### Row 48

**Each character's HP bar**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E48`. Source maximum/points: `C48` / `F48`.

### Row 49

**Each character's SP bar**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E49`. Source maximum/points: `C49` / `F49`.

### Row 50

**Each character's skill icon**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E50`. Source maximum/points: `C50` / `F50`.

### Row 51

**Skill icon cooldown**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E51`. Source maximum/points: `C51` / `F51`.

### Row 52

**Each character's action point**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E52`. Source maximum/points: `C52` / `F52`.

### Row 57

**Enemy's turn UI**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E57`. Source maximum/points: `C57` / `F57`.

### Row 58

**Enemy's health bar**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E58`. Source maximum/points: `C58` / `F58`.

### Row 63

**Menu Overlay**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E63`. Source maximum/points: `C63` / `F63`.

### Row 64

**Use item while in the battle**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E64`. Source maximum/points: `C64` / `F64`.

### Row 65

**Save and quit**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E65`. Source maximum/points: `C65` / `F65`.

### Row 70

**Player's returning to location where the enemy was first encountered**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E70`. Source maximum/points: `C70` / `F70`.

### Row 71

**Defeated enemy not appearing again**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E71`. Source maximum/points: `C71` / `F71`.

### Row 76

**End turns**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E76`. Source maximum/points: `C76` / `F76`.

### Row 77

**Rotate camera**

Read [Exploration camera, zoom, overworld map, and dungeon reveal](../Features/18-cameras-and-maps.md) for the behavior, code flow, and demonstration. Source score: `Battle!E77`. Source maximum/points: `C77` / `F77`.

### Row 78

**Move**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E78`. Source maximum/points: `C78` / `F78`.

### Row 79

**Selecting skills**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E79`. Source maximum/points: `C79` / `F79`.

### Row 80

**Confirm skill**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E80`. Source maximum/points: `C80` / `F80`.

### Row 81

**Aiming & Charging (RandaL)**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E81`. Source maximum/points: `C81` / `F81`.

### Row 82

**Rotate camera**

Read [Exploration camera, zoom, overworld map, and dungeon reveal](../Features/18-cameras-and-maps.md) for the behavior, code flow, and demonstration. Source score: `Battle!E82`. Source maximum/points: `C82` / `F82`.

### Row 83

**Change character**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E83`. Source maximum/points: `C83` / `F83`.

### Row 84

**Esc to menu**

Read [Encounters, party turns, AP, cover, victory, and returns](../Features/20-battle-system.md) for the behavior, code flow, and demonstration. Source score: `Battle!E84`. Source maximum/points: `C84` / `F84`.
