# NPC: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `NPC`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 7 | Dialogue UI | 2 | 0.3 | 0.15 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [NPCSpeechBubble.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs>) |
| 8 | Dialogue type | 2 | 0.6 | 0.3 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [NPCBase.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs>) |
| 9 | Dialogue skip | 4 | 0.3 | 0.3 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [NPCBase.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs>) |
| 10 | Dialogue area trigger | 4 | 0.3 | 0.3 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [NPCBase.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs>) |
| 15 | NPC random distribution in overworld | 3 | 0.15 | 0.1125 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [NPCSpawner.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs>) |
| 16 | NPC random distribution in dungeon | 3 | 0.15 | 0.1125 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [DungeonGenerator.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonGenerator.cs>) |
| 21 | Open the interaction overlay | 3 | 0.2 | 0.15 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [InteractableNPC.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs>) |
| 22 | Interactable NPC random distribution in overworld | 2 | 0.2 | 0.1 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [NPCSpawner.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs>) |
| 23 | Interactable NPC random distribution in dungeon | 3 | 0.2 | 0.15 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [DungeonGenerator.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonGenerator.cs>) |
| 28 | Berdly NPC in overworld | 4 | 0.2 | 0.2 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [MinigameNPC.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs>) |
| 29 | Pink NPC in overworld | 4 | 0.2 | 0.2 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [MinigameNPC.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs>) |
| 30 | Exclusive theme | 4 | 0.1 | 0.1 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [OverworldMusicController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/OverworldMusicController.cs>) |
| 31 | Minigame overlay | 3 | 0.1 | 0.075 | [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) | [NPCChallengePrompt.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/NPCChallengePrompt.cs>) |

## Row locators

### Row 7

**Dialogue UI**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Dialogue type**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E8`. Source maximum/points: `C8` / `F8`.

### Row 9

**Dialogue skip**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E9`. Source maximum/points: `C9` / `F9`.

### Row 10

**Dialogue area trigger**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E10`. Source maximum/points: `C10` / `F10`.

### Row 15

**NPC random distribution in overworld**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E15`. Source maximum/points: `C15` / `F15`.

### Row 16

**NPC random distribution in dungeon**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E16`. Source maximum/points: `C16` / `F16`.

### Row 21

**Open the interaction overlay**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E21`. Source maximum/points: `C21` / `F21`.

### Row 22

**Interactable NPC random distribution in overworld**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E22`. Source maximum/points: `C22` / `F22`.

### Row 23

**Interactable NPC random distribution in dungeon**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E23`. Source maximum/points: `C23` / `F23`.

### Row 28

**Berdly NPC in overworld**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E28`. Source maximum/points: `C28` / `F28`.

### Row 29

**Pink NPC in overworld**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E29`. Source maximum/points: `C29` / `F29`.

### Row 30

**Exclusive theme**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E30`. Source maximum/points: `C30` / `F30`.

### Row 31

**Minigame overlay**

Read [NPC dialogue, proximity, shops, and challenge prompts](../Features/09-npc-dialogue.md) for the behavior, code flow, and demonstration. Source score: `NPC!E31`. Source maximum/points: `C31` / `F31`.
