# Item: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `Item`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 6 | Item Menu | 4 | 0.4 | 0.4 | [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) | [InventoryUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/InventoryUI.cs>) |
| 7 | Using each item to increase HP & SP | 4 | 0.6 | 0.6 | [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) | [Consumable.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Consumable.cs>) |
| 8 | Show preview when increasing HP & SP | 4 | 0.2 | 0.2 | [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) | [InventoryUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/InventoryUI.cs>) |
| 9 | Not showing item that have quantity of 0 | 4 | 0.2 | 0.2 | [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) | [InventoryUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/InventoryUI.cs>) |
| 10 | All items are implemented | 4 | 0.6 | 0.6 | [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) | [Consumable.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Inventory/Consumable.cs>) |

## Row locators

### Row 6

**Item Menu**

Read [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) for the behavior, code flow, and demonstration. Source score: `Item!E6`. Source maximum/points: `C6` / `F6`.

### Row 7

**Using each item to increase HP & SP**

Read [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) for the behavior, code flow, and demonstration. Source score: `Item!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Show preview when increasing HP & SP**

Read [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) for the behavior, code flow, and demonstration. Source score: `Item!E8`. Source maximum/points: `C8` / `F8`.

### Row 9

**Not showing item that have quantity of 0**

Read [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) for the behavior, code flow, and demonstration. Source score: `Item!E9`. Source maximum/points: `C9` / `F9`.

### Row 10

**All items are implemented**

Read [Inventory, consumables, HP/SP preview, and Diamond](../Features/10-items.md) for the behavior, code flow, and demonstration. Source score: `Item!E10`. Source maximum/points: `C10` / `F10`.
