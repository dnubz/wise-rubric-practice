# Boss Battle: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `Boss Battle`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 7 | Battle transition | 0 | 0.08 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleSession.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSession.cs>) |
| 8 | Boss dialogue | 0 | 0.08 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossDialogue.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossDialogue.cs>) |
| 9 | Skip dialogue with F | 0 | 0.08 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossDialogue.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossDialogue.cs>) |
| 14 | Jevil summoning enemies | 0 | 0.311351 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 15 | Jevil's kidnap player | 0 | 0.311351 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) |
| 16 | Jevil's attack pattern 1 | 0 | 0.934054 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |
| 17 | Jevil's attack pattern 2 | 0 | 0.934054 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |
| 18 | Jevil's attack pattern 3 | 0 | 1.08973 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |
| 19 | Jevil's attack pattern 4 | 0 | 0.934054 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |
| 20 | Jevil's attack pattern 5 | 0 | 0.311351 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |
| 21 | Heart movement | 0 | 0.155676 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |
| 22 | Collision handling | 0 | 0.467027 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |
| 23 | Damage formula | 0 | 0.155676 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) |
| 24 | Invincibility | 0 | 0.155676 | 0 | [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) | [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) |

## Row locators

### Row 7

**Battle transition**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Boss dialogue**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E8`. Source maximum/points: `C8` / `F8`.

### Row 9

**Skip dialogue with F**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E9`. Source maximum/points: `C9` / `F9`.

### Row 14

**Jevil summoning enemies**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E14`. Source maximum/points: `C14` / `F14`.

### Row 15

**Jevil's kidnap player**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E15`. Source maximum/points: `C15` / `F15`.

### Row 16

**Jevil's attack pattern 1**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E16`. Source maximum/points: `C16` / `F16`.

### Row 17

**Jevil's attack pattern 2**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E17`. Source maximum/points: `C17` / `F17`.

### Row 18

**Jevil's attack pattern 3**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E18`. Source maximum/points: `C18` / `F18`.

### Row 19

**Jevil's attack pattern 4**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E19`. Source maximum/points: `C19` / `F19`.

### Row 20

**Jevil's attack pattern 5**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E20`. Source maximum/points: `C20` / `F20`.

### Row 21

**Heart movement**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E21`. Source maximum/points: `C21` / `F21`.

### Row 22

**Collision handling**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E22`. Source maximum/points: `C22` / `F22`.

### Row 23

**Damage formula**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E23`. Source maximum/points: `C23` / `F23`.

### Row 24

**Invincibility**

Read [Jevil dialogue, summoning, kidnapping, and five dodge patterns](../Features/24-jevil-boss.md) for the behavior, code flow, and demonstration. Source score: `Boss Battle!E24`. Source maximum/points: `C24` / `F24`.
