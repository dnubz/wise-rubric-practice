# IUPAC Algorithm: workbook checklist

[Guide home](../README.md) · [Workbook scoring explanation](../02-workbook-and-scoring.md)

Source: [!Scoring Game 26-2 JT.xlsx](<C:/Users/Ezell/Downloads/!Scoring Game 26-2 JT.xlsx>). Sheet `IUPAC Algorithm`. Values below are stored workbook values; formulas were inspected but not recalculated.

Score is the workbook's 0–4 assessment input. Maximum and harvested points can be formula caches or manual values. These are not new implementation grades.

| Source row | Requirement | Score / 4 | Max points | Recorded points | Teaching chapter | Main source |
| --- | --- | --- | --- | --- | --- | --- |
| 5 | Determine longest chain (Degree-1) | 0 | 0.15 | 0 | [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) | [BerdlyMolecule.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMolecule.cs>) |
| 6 | Determine numbering order of the chain | 0 | 0.15 | 0 | [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) | [BerdlyMolecule.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMolecule.cs>) |
| 7 | Determine other degree (Degree-n+1) | 0 | 0.3 | 0 | [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) | [BerdlyMolecule.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMolecule.cs>) |
| 8 | Naming algorithm | 0 | 0.4 | 0 | [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) | [BerdlyMolecule.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMolecule.cs>) |

## Row locators

### Row 5

**Determine longest chain (Degree-1)**

Read [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) for the behavior, code flow, and demonstration. Source score: `IUPAC Algorithm!E5`. Source maximum/points: `C5` / `F5`.

### Row 6

**Determine numbering order of the chain**

Read [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) for the behavior, code flow, and demonstration. Source score: `IUPAC Algorithm!E6`. Source maximum/points: `C6` / `F6`.

### Row 7

**Determine other degree (Degree-n+1)**

Read [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) for the behavior, code flow, and demonstration. Source score: `IUPAC Algorithm!E7`. Source maximum/points: `C7` / `F7`.

### Row 8

**Naming algorithm**

Read [The shared molecule and dungeon naming algorithm](../Features/26-iupac-algorithm.md) for the behavior, code flow, and demonstration. Source score: `IUPAC Algorithm!E8`. Source maximum/points: `C8` / `F8`.

## Separate understanding questions

The sheet also has Question 1 (`B13`, maximum `C13=4`, score `D13=0`) and Question 2 (`B14`, maximum `C14=4`, score `D14=0`). Their question text is not present in the supplied workbook, so this guide cannot reproduce it. `C11` scales the algorithm subtotal by those question scores through `F9`.
