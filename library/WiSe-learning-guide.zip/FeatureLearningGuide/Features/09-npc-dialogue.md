# NPC dialogue, proximity, shops, and challenge prompts

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `NPC`.

## What the player sees

Approaching an NPC starts dialogue in a speech bubble. Text appears progressively. F completes a typing sentence; a later F advances or performs the final interaction.

## Shared dialogue flow

`NPCBase` finds the active character, measures distance to the collider's closest point, and detects entering/exiting its proximity range. Entering can greet and begin dialogue. A coroutine reveals text at `typingSpeed`. Finishing typing shows the interaction prompt. Leaving range or disabling the NPC ends dialogue and stops its coroutine.

Measuring to the collider helps large models: their pivot may be far from the player even when the player stands beside the body. NPCs can rotate toward the player and return to their initial facing.

## Three NPC roles

| Type | What happens after dialogue |
| --- | --- |
| NormalNPC | Presents ordinary dialogue/guide information. |
| InteractableNPC | Opens its ShopInventory, resource selling UI, or assigned UnityEvent. |
| MinigameNPC | Opens a Yes/No challenge prompt for Berdly chemistry or Pink rhythm. |

Accept opens the matching controller. Decline/leave/disable closes the pending prompt. Modal input blocking prevents a number-key answer or F press from also acting in the world.

## Distribution and themes

`NPCSpawner` uses seeded per-chunk placement on valid terrain, avoiding building footprints. DungeonGenerator places guide/friendly NPC content separately. Do not assume every overworld NPC subtype is also spawned in every dungeon.

Minigame NPCs register with `OverworldMusicController`. Proximity switches to their exclusive theme, and leaving restores the world music. Berdly battle and rhythm can take ownership of the music state.

## Scripts to read

- [NPCBase.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs>) — [included copy](../Scripts/Assets/Scripts/NPC/NPCBase.cs).
- [NormalNPC.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NormalNPC.cs>) — [included copy](../Scripts/Assets/Scripts/NPC/NormalNPC.cs).
- [InteractableNPC.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/InteractableNPC.cs>) — [included copy](../Scripts/Assets/Scripts/NPC/InteractableNPC.cs).
- [MinigameNPC.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/MinigameNPC.cs>) — [included copy](../Scripts/Assets/Scripts/NPC/MinigameNPC.cs).
- [NPCSpeechBubble.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCSpeechBubble.cs>) — [included copy](../Scripts/Assets/Scripts/NPC/NPCSpeechBubble.cs).
- [NPCChallengePrompt.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/NPCChallengePrompt.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/NPCChallengePrompt.cs).
- [NPCSpawner.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/NPCSpawner.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/NPCSpawner.cs).

## Small piece of the actual code

From [NPCBase.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/NPC/NPCBase.cs:174>) (line 174). This is an excerpt; continue in the full script for context.

```csharp
protected virtual void OnFKeyPressed()
{
    if (isTyping)
    {
        // Skip typing and finish current sentence immediately
        FinishTypingCurrentSentence();
    }
    else
    {
        OnFKeyPressedAfterSentence();
    }
}

```

## Demonstrate it yourself

Approach a normal NPC, press F while typing, then F again after completion. Repeat with a shop NPC and a challenge NPC. Choose No once, then Yes; check that dialogue, prompt, and gameplay inputs do not overlap.

## Explain it in one answer

“NPCBase owns proximity and typing. Derived NPC types decide the final action: ordinary dialogue, a shop, or a challenge prompt.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `NPC!B7`: Dialogue UI — [rubric row](../Rubric/NPC.md#row-7).
- `NPC!B8`: Dialogue type — [rubric row](../Rubric/NPC.md#row-8).
- `NPC!B9`: Dialogue skip — [rubric row](../Rubric/NPC.md#row-9).
- `NPC!B10`: Dialogue area trigger — [rubric row](../Rubric/NPC.md#row-10).
- `NPC!B15`: NPC random distribution in overworld — [rubric row](../Rubric/NPC.md#row-15).
- `NPC!B16`: NPC random distribution in dungeon — [rubric row](../Rubric/NPC.md#row-16).
- `NPC!B21`: Open the interaction overlay — [rubric row](../Rubric/NPC.md#row-21).
- `NPC!B22`: Interactable NPC random distribution in overworld — [rubric row](../Rubric/NPC.md#row-22).
- `NPC!B23`: Interactable NPC random distribution in dungeon — [rubric row](../Rubric/NPC.md#row-23).
- `NPC!B28`: Berdly NPC in overworld — [rubric row](../Rubric/NPC.md#row-28).
- `NPC!B29`: Pink NPC in overworld — [rubric row](../Rubric/NPC.md#row-29).
- `NPC!B30`: Exclusive theme — [rubric row](../Rubric/NPC.md#row-30).
- `NPC!B31`: Minigame overlay — [rubric row](../Rubric/NPC.md#row-31).
- `Overworld!B41`: Interact — [rubric row](../Rubric/Overworld.md#row-41).
