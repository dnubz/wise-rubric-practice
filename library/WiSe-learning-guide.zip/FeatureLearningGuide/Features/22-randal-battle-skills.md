# RandaL battle skills: lock-on, SP buff, portal, and barrage

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Skills`.

## Four abilities

RandaL.cs owns exploration book placement. BattleController's `characterIndex == 1` branches own the battle effects.

| Slot/key | Behavior |
| --- | --- |
| Basic / 1 | Locks a live enemy in range. A/D cycles candidates. Fires a projectile with magic-adjusted `10 + Attack`. |
| First skill / 2 | Restores SP to living allies in radius and adds a two-turn magic buff. |
| Second skill / 3 | Opens portal state and reduces the other three cooldown slots by one, never below zero. |
| Ultimate / 4 | Arcane Barrage enters first person for up to ten seconds. Hold/release left mouse to charge/fire. |

## Buff and portal rules

Ordinary first skill restores rounded `(5 + Attack) × 1.6` SP and grants a 30% magic buff. Portal-empowered use multiplies that restoration by 1.5 and grants 40%. The helper `Magic` applies the actor's current magicBuff multiplier to raw magic damage.

Portal empowers the next non-portal ability and is then consumed. Empowered basic projectiles can bounce through up to two additional nearby living enemies. Portal reduces RandaL's own other cooldowns; it does not loop over every party member's cooldowns. Explain this concrete scope when demonstrating the rubric's “Lower all cooldown by 1.”

## Arcane Barrage

The camera becomes first person, a crosshair appears, and party visuals become partly transparent. Charge caps at 1.5 seconds. Releasing launches toward the center-camera ray, with size/damage interpolated by charge and a shot interval of 0.5 seconds. A near-full portal-empowered charge enables bounce behavior.

At completion the controller waits for outstanding shots, stops charge sound, hides the crosshair, restores third-person camera, and restores ally visibility. Opening the menu pauses the sequence/charge audio until resumed.

RandaL's ultimate has no HasUltimate requirement in `CanUse`; the unlock check explicitly exempts selected character index 1. AP/SP/cooldown still apply.

## Scripts to read

- [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleController.cs).
- [BattleSkill.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSkill.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleSkill.cs).
- [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleUnit.cs).
- [BattleCamera.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleCamera.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleCamera.cs).
- [BattleProjectile.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleProjectile.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleProjectile.cs).

## Small piece of the actual code

From [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs:252>) (line 252). This is an excerpt; continue in the full script for context.

```csharp
else if (skill.slot == 2) { actor.portal = true; for (int i = 0; i < 4; i++) if (i != 2) actor.character.BattleCooldowns[i] = Mathf.Max(0, actor.character.BattleCooldowns[i] - 1); Popup(actor.transform.position, "PORTAL OPEN", Color.magenta); }
```

## Demonstrate it yourself

Lock a target and cycle with A/D. Cast the SP skill and inspect buff feedback. Cast portal and compare cooldowns, then consume it with a basic. For the ultimate, show uncharged/full-charge shots and camera restoration.

## Explain it in one answer

“RandaL uses lock-on projectiles and a two-turn magic buff. Portal modifies the next skill and reduces his other cooldowns. Barrage temporarily owns the first-person camera and charges shots by held input.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Skills!B44`: Target lock — [rubric row](../Rubric/Skills.md#row-44).
- `Skills!B45`: Change locked target — [rubric row](../Rubric/Skills.md#row-45).
- `Skills!B46`: Buffed state — [rubric row](../Rubric/Skills.md#row-46).
- `Skills!B47`: Fireball as projectile — [rubric row](../Rubric/Skills.md#row-47).
- `Skills!B52`: Restore SP and gain a 30% magic power buff — [rubric row](../Rubric/Skills.md#row-52).
- `Skills!B53`: Buff other character in area — [rubric row](../Rubric/Skills.md#row-53).
- `Skills!B54`: Buffed state — [rubric row](../Rubric/Skills.md#row-54).
- `Skills!B59`: Open portal state — [rubric row](../Rubric/Skills.md#row-59).
- `Skills!B60`: Lower all cooldown by 1 — [rubric row](../Rubric/Skills.md#row-60).
- `Skills!B65`: Change into first person perspective — [rubric row](../Rubric/Skills.md#row-65).
- `Skills!B66`: Crosshair — [rubric row](../Rubric/Skills.md#row-66).
- `Skills!B67`: Allies semi-transparent — [rubric row](../Rubric/Skills.md#row-67).
- `Skills!B68`: Aim and shoot projectiles — [rubric row](../Rubric/Skills.md#row-68).
- `Skills!B69`: Charging projectile — [rubric row](../Rubric/Skills.md#row-69).
- `Skills!B70`: Buffed state — [rubric row](../Rubric/Skills.md#row-70).
- `Skills!B71`: Change back to third person perspective — [rubric row](../Rubric/Skills.md#row-71).
- `Skills!B76`: Animation — [rubric row](../Rubric/Skills.md#row-76).
- `Skills!B77`: SFX — [rubric row](../Rubric/Skills.md#row-77).
