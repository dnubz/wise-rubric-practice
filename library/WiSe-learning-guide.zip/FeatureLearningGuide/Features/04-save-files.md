# Three binary save slots and restoring a playthrough

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Save File`.

## What gets saved

Three independent `slot-1.sav` through `slot-3.sav` files live beneath `Application.persistentDataPath/Saves`. They contain party stats/progress, equipment, inventory copies, gold, selected character, world seed/settings, position, opened chests, defeated encounters, audio/display settings, playtime, and visited dungeon layouts/progress.

## Saving, step by step

1. `GameSave.Capture` converts live scene state into plain `SaveData`.
2. Items/equipment are recorded by names resolved through the item catalog.
3. `BinarySaveFile.Write` validates the data and writes primitives/arrays in a fixed order.
4. A header stores `WISE`, schema version 3, payload length, and SHA-256 checksum.
5. The complete temporary file replaces the prior file. Save & Quit returns to the title only after a successful write.

## Loading, step by step

Read verifies size, version, checksum, and value bounds before scene restoration. GameSave runs early and installs the saved world seed before generation. Later it restores party/inventory and dungeon progress, then reveals the scene.

Version 2 binary saves are readable. A legacy version 1 JSON file has a one-time import path. A checksum detects corruption; it is not encryption or proof a file has not been deliberately edited.

## Why binary is used

Fixed primitive values avoid JSON field-name/text-number overhead and make the schema explicit. The tradeoff is that reader and writer must agree on field order and version. This uses BinaryReader/BinaryWriter, not BinaryFormatter.

## Restore behavior to remember

- Continue is based on **last played**, not only last saved.
- A dungeon save resumes in its first room with its layout/progress, not the exact saved room position.
- An ordinary battle save restores the encounter return position; it does not resume halfway through an attack animation.
- Save is rejected during travel.
- Deletion requires the title UI confirmation and affects one slot.

Seeds reproduce generated terrain under the current algorithm. Changing that algorithm can require save migration even if the stored seed stays the same.

## Scripts to read

- [GameSave.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/GameSave.cs>) — [included copy](../Scripts/Assets/Scripts/Save/GameSave.cs).
- [BinarySaveFile.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/BinarySaveFile.cs>) — [included copy](../Scripts/Assets/Scripts/Save/BinarySaveFile.cs).
- [SavedLayouts.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/SavedLayouts.cs>) — [included copy](../Scripts/Assets/Scripts/Save/SavedLayouts.cs).
- [SaveItemCatalog.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/SaveItemCatalog.cs>) — [included copy](../Scripts/Assets/Scripts/Save/SaveItemCatalog.cs).
- [SaveGameSettings.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/SaveGameSettings.cs>) — [included copy](../Scripts/Assets/Scripts/Save/SaveGameSettings.cs).
- [SaveSlotUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs>) — [included copy](../Scripts/Assets/Scripts/UI/MainMenu/SaveSlotUI.cs).
- [ContinueSaveUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs>) — [included copy](../Scripts/Assets/Scripts/UI/MainMenu/ContinueSaveUI.cs).
- [QuitMenuUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/QuitMenuUI.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/QuitMenuUI.cs).

## Small piece of the actual code

From [BinarySaveFile.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/BinarySaveFile.cs:14>) (line 14). This is an excerpt; continue in the full script for context.

```csharp
public static void Write(string path, GameSave.SaveData data)
{
    Validate(data);
    byte[] payload;
    using (var stream = new MemoryStream())
    {
        using (var w = new BinaryWriter(stream, Utf8, true)) WriteData(w, data);
        payload = stream.ToArray();
    }
    if (payload.Length > MaxBytes) throw new InvalidDataException("Save exceeds the supported size.");
    string directory = Path.GetDirectoryName(Path.GetFullPath(path)); Directory.CreateDirectory(directory);
    string temporary = path + ".tmp";
    try
    {
        using (var stream = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None))
        using (var w = new BinaryWriter(stream, Utf8))
        using (var sha = SHA256.Create())
```

## Demonstrate it yourself

Use a spare slot. Gain gold or an item, switch character, save through Quit, then Continue and compare. In a dungeon, open a progression chest, save, and confirm the first-room resume plus preserved key/chest state. Do not use your only valuable slot for deletion testing.

## Explain it in one answer

“Capture makes a data snapshot, the binary writer stores an explicit versioned schema with a corruption checksum, and loading restores the seed before generating the world.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Save File!B6`: Save using binary — [rubric row](../Rubric/Save-File.md#row-6).
- `Save File!B7`: Why use binary — [rubric row](../Rubric/Save-File.md#row-7).
- `Save File!B8`: 3 save files — [rubric row](../Rubric/Save-File.md#row-8).
- `Save File!B9`: Delete save file — [rubric row](../Rubric/Save-File.md#row-9).
- `Save File!B10`: Saving according to the criteria — [rubric row](../Rubric/Save-File.md#row-10).
- `Save File!B11`: Saving through menu — [rubric row](../Rubric/Save-File.md#row-11).
