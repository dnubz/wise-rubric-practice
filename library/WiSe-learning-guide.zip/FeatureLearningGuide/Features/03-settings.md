# Music, SFX, frame rate, resolution, and fullscreen

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Settings`.

## What the player changes

Music and SFX have separate levels. FPS choices, resolution, and window mode affect the application across scenes.

## How it works

`SettingsUI` reads saved preferences in `Awake`. Left/right resolution buttons choose among 1280×720, 1920×1080, and 3840×2160. `ApplySettings` calls `Screen.SetResolution` and saves width, height, and fullscreen preference. The fullscreen toggle changes the mode immediately and stores it.

`FPS` exposes the frame-rate button handlers. `GameAudio` routes music and effects into separate mixer groups, stores volume preferences, and applies them centrally. `GameAudioBootstrap` makes settings available when scenes start. `GameAudioMenuUI` connects the in-game sliders to the same audio behavior.

## Why it survives a scene change

`PlayerPrefs` keeps application settings. Scene audio sources are routed to shared mixer groups, so adjusting the group affects multiple sources. Save slots additionally capture `SaveGameSettings`, allowing a loaded playthrough to restore its saved configuration.

## Things to explain precisely

- A target FPS is a limit/request, not a guarantee the hardware can sustain that rate.
- Selecting a resolution and applying it are separate operations.
- The fullscreen button text describes the alternative action (`Windowed` while fullscreen is active).
- Muting SFX should not mute music. Test both independently.

For the “configuration affected every scene” criterion, demonstrate a setting before and after travel rather than pointing only at PlayerPrefs calls.

## Scripts to read

- [SettingsUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Settings/SettingsUI.cs>) — [included copy](../Scripts/Assets/Scripts/UI/MainMenu/Settings/SettingsUI.cs).
- [AudioSettingsUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Settings/AudioSettingsUI.cs>) — [included copy](../Scripts/Assets/Scripts/UI/MainMenu/Settings/AudioSettingsUI.cs).
- [FPS.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Settings/FPS.cs>) — [included copy](../Scripts/Assets/Scripts/UI/MainMenu/Settings/FPS.cs).
- [GameAudio.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudio.cs>) — [included copy](../Scripts/Assets/Scripts/Audio/GameAudio.cs).
- [GameAudioBootstrap.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Audio/GameAudioBootstrap.cs>) — [included copy](../Scripts/Assets/Scripts/Audio/GameAudioBootstrap.cs).
- [GameAudioMenuUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/GameAudioMenuUI.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/GameAudioMenuUI.cs).
- [SaveGameSettings.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Save/SaveGameSettings.cs>) — [included copy](../Scripts/Assets/Scripts/Save/SaveGameSettings.cs).

## Small piece of the actual code

From [SettingsUI.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/MainMenu/Settings/SettingsUI.cs:97>) (line 97). This is an excerpt; continue in the full script for context.

```csharp
public void ApplySettings()
{
    var res = resolutions[selectedIdx];
    FullScreenMode mode = isFullscreen ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;
    Screen.SetResolution(res.width, res.height, mode);
    PlayerPrefs.SetInt("ScreenWidth", res.width); PlayerPrefs.SetInt("ScreenHeight", res.height);
    PlayerPrefs.SetInt("Fullscreen", isFullscreen ? 1 : 0); PlayerPrefs.Save();
}

```

## Demonstrate it yourself

Lower music while leaving SFX audible. Click a title button to hear the difference. Apply a resolution/window mode and an FPS choice, enter the overworld, then inspect the in-game audio menu and confirm the configuration carried across.

## Explain it in one answer

“The settings UI changes saved preferences and engine settings. Shared mixer routing applies music/SFX levels to scene sources, and save slots also capture the configuration.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Settings!B6`: Settings overlay — [rubric row](../Rubric/Settings.md#row-6).
- `Settings!B7`: Configuration affected every scene — [rubric row](../Rubric/Settings.md#row-7).
- `Settings!B8`: Music bar — [rubric row](../Rubric/Settings.md#row-8).
- `Settings!B9`: SFX bar — [rubric row](../Rubric/Settings.md#row-9).
- `Settings!B10`: Frame rate — [rubric row](../Rubric/Settings.md#row-10).
- `Settings!B11`: Resolution — [rubric row](../Rubric/Settings.md#row-11).
- `Settings!B12`: Fullscreen & windowed — [rubric row](../Rubric/Settings.md#row-12).
