# Dungeon room graphs, chains, keys, and floor WFC

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Dungeon`, `IUPAC Algorithm`.

## Two different generation jobs

DungeonLayout makes the room/door graph and progression data. DungeonGenerator builds rooms and contents from that data. DungeonFloorWFC chooses each room's floor tiles. The floor WFC does not decide the entire dungeon room graph.

## Room graph generation

1. A seeded random walk collects adjacent grid positions.
2. All orthogonally adjacent positions become possible edges with random weights.
3. Kruskal's algorithm sorts edges and uses disjoint sets to reject cycles, producing a minimum spanning tree.
4. The naming algorithm selects the main chain and recursively selects branches.
5. Each room gets a chain index, one-based position, chain degree, random size, and initial kind.
6. The first main-chain room becomes Spawn, the second Guide/Berdly, and the last Boss.
7. Progression keys and door locks are assigned, then the shared chemistry algorithm produces the dungeon name.

The configured default range in DungeonSettings is 14–24 rooms. A selected parent chain is limited to 11 rooms, even when the whole graph has more. Bounded retries reject unsuitable graphs and enforce enough branching for larger dungeons.

## Key placement rules in the current code

Two original keys are placed in distinct non-boss main-chain rooms. Branch endpoints receive original keys to replenish keys spent entering branches. One endpoint at the deepest chain degree is selected to hold the boss key instead. Doors between chains require original keys; doors into the boss room require the boss key.

**Numbering detail:** room Degree here means nesting depth of the selected naming chain. It does not mean the graph-theory count of incident doors.

## Rooms and floor generation

Rooms may be Normal, Treasure, Enemy, Guide, Spawn, or Boss. Dimensions come from settings, independently per room. Floor WFC has brick/slab/cracked/moss options with weights 50/30/14/6. Edges and central crossings allow clear stone types. Moss cannot touch cracked tiles or another moss tile. DungeonGenerator batches floor meshes by material for drawing.

The original workbook's zero on Enemy room is a recorded assessment value; current Generator/EnemySpawner paths exist and should be demonstrated.

## Scripts to read

- [DungeonLayout.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonLayout.cs>) — [included copy](../Scripts/Assets/Scripts/Dungeon/DungeonLayout.cs).
- [DungeonGenerator.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonGenerator.cs>) — [included copy](../Scripts/Assets/Scripts/Dungeon/DungeonGenerator.cs).
- [DungeonSettings.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonSettings.cs>) — [included copy](../Scripts/Assets/Scripts/Dungeon/DungeonSettings.cs).
- [DungeonFloorWFC.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonFloorWFC.cs>) — [included copy](../Scripts/Assets/Scripts/Dungeon/DungeonFloorWFC.cs).
- [BerdlyMolecule.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMolecule.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/BerdlyMolecule.cs).

## Small piece of the actual code

From [DungeonLayout.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonLayout.cs:84>) (line 84). This is an excerpt; continue in the full script for context.

```csharp
    // Every non-boss branch replenishes the key spent entering it,
    // so exploring branches in any order cannot exhaust yellow keys.
    result.Rooms[end].Key = DungeonKeyKind.Original;
    if (result.Rooms[end].Degree == result.MaximumDegree) deepest.Add(end);
}
result.Rooms[deepest[random.Next(deepest.Count)]].Key = DungeonKeyKind.Boss;
// Required key loot belongs in a treasure room, never an ordinary decoration-only room.
// The fixed second room remains the guide room even when it holds a progression key.
foreach (DungeonRoomData room in result.Rooms)
```

## Demonstrate it yourself

Enter a dungeon and compare the reported room count/name with its map. Find the main chain, a branch, key chests, and the boss gate. Generate a different entrance and observe variation; use the explicit fixed-seed setting for reproducible study.

## Explain it in one answer

“A random walk supplies positions, Kruskal builds a connected tree, recursive naming selects chains, and progression rules assign keys/locks. A separate WFC decorates each room's floor.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Dungeon!B7`: Dungeon Generation — [rubric row](../Rubric/Dungeon.md#row-7).
- `Dungeon!B13`: Spawn room — [rubric row](../Rubric/Dungeon.md#row-13).
- `Dungeon!B14`: Boss room — [rubric row](../Rubric/Dungeon.md#row-14).
- `Dungeon!B15`: Original key placement in degree-1 — [rubric row](../Rubric/Dungeon.md#row-15).
- `Dungeon!B16`: Branch door are locked with original key — [rubric row](../Rubric/Dungeon.md#row-16).
- `Dungeon!B17`: Boss room locked with different key (boss key) — [rubric row](../Rubric/Dungeon.md#row-17).
- `Dungeon!B18`: Original key placement in the last room of every branch — [rubric row](../Rubric/Dungeon.md#row-18).
- `Dungeon!B19`: Boss key placement in the last room of last branch — [rubric row](../Rubric/Dungeon.md#row-19).
- `Dungeon!B20`: Chest for key — [rubric row](../Rubric/Dungeon.md#row-20).
- `Dungeon!B25`: Randomized room size — [rubric row](../Rubric/Dungeon.md#row-25).
