# Exploration camera, zoom, overworld map, and dungeon reveal

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Overworld`, `Dungeon`, `Battle`.

## Three related systems

Exploration CameraController follows the selected character and transitions among configured camera views. BattleCamera follows battle units and has its own orbit/first-person behavior. The maps present world information through UI, rather than operating as another gameplay camera.

## Exploration controls

Q/E changes the camera view through the ChangeCam action. The scroll wheel changes field of view within configured limits, with smoothing. CameraController follows CharacterSwitchManager's transform event and can snap immediately after a teleport. Dungeon mode stores/restores camera configuration and provides a steeper view.

The workbook says “rotate camera.” In the exploration implementation, explain the actual configured-view transition rather than claiming an unrestricted free orbit.

## Overworld map

OverworldMinimap creates a Texture2D and paints a player-centered terrain preview from the same world queries. It redraws for a changed tile or seed rather than continuously rebuilding every pixel. Map rotation follows the camera source. M toggles visibility. Hover/scroll map focus allows map zoom without simultaneously zooming the gameplay camera.

Visual colors can use terrain blend information, but the collapsed WFC terrain remains the gameplay type. Minimap prequeries can fill logical terrain caches without instantiating all visible objects; chunk generation uses independent seeds to avoid query-order changes.

## Dungeon map

Rooms and door connections form the grid. Visiting a room marks it visited and reveals it plus its immediate neighbors. Revealed and visited are separate sets. The active character portrait marks the current room. Camera rotation rotates the map; UI panning moves the preview without rebuilding the texture.

`showmain` reveals/highlights the main chain; `revealall` reveals all rooms and colors by chain degree. These reveal commands do not mean those rooms were actually visited.

## Battle camera

BattleCamera follows the selected party member, or focuses an enemy during its action. Q/E orbits, scroll changes distance/tilt, and RandaL's ultimate temporarily enters first person. Camera state is restored after special sequences.

## Scripts to read

- [CameraController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Camera/CameraController.cs>) — [included copy](../Scripts/Assets/Scripts/Camera/CameraController.cs).
- [OverworldMinimap.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/OverworldMinimap.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/OverworldMinimap.cs).
- [DungeonMinimap.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonMinimap.cs>) — [included copy](../Scripts/Assets/Scripts/Dungeon/DungeonMinimap.cs).
- [BattleCamera.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleCamera.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleCamera.cs).

## Small piece of the actual code

From [DungeonMinimap.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonMinimap.cs:59>) (line 59). This is an excerpt; continue in the full script for context.

```csharp
public void Visit(int room)
{
    visited.Add(room); revealed.Add(room);
    foreach (int neighbour in dungeon.Layout.Graph.Bonds[room]) revealed.Add(neighbour);
    Paint();
    Vector2 current = Centre(room); map.anchoredPosition = -current; icon.anchoredPosition = current;
}
```

## Demonstrate it yourself

Press M and change the exploration view with Q/E. Zoom normally, then while hovering the map. In a dungeon, enter a room and explain the difference between newly revealed neighbors and already visited rooms. Compare battle camera controls separately.

## Explain it in one answer

“Exploration uses configured camera views and FOV zoom. The overworld map samples seeded terrain, while the dungeon map reveals graph neighbors and tracks visits separately.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Dungeon!B38`: Grid-based map — [rubric row](../Rubric/Dungeon.md#row-38).
- `Dungeon!B39`: Character icon — [rubric row](../Rubric/Dungeon.md#row-39).
- `Dungeon!B40`: Moving minimap's preview — [rubric row](../Rubric/Dungeon.md#row-40).
- `Dungeon!B41`: Reveal minimap sequentially — [rubric row](../Rubric/Dungeon.md#row-41).
- `Dungeon!B42`: Each grid connection (doorway) — [rubric row](../Rubric/Dungeon.md#row-42).
- `Dungeon!B43`: Visited room — [rubric row](../Rubric/Dungeon.md#row-43).
- `Dungeon!B44`: Rotate the map if camera rotated — [rubric row](../Rubric/Dungeon.md#row-44).
- `Dungeon!B49`: Rotate camera — [rubric row](../Rubric/Dungeon.md#row-49).
- `Dungeon!B51`: Show/unshow minimap — [rubric row](../Rubric/Dungeon.md#row-51).
- `Dungeon!B54`: Zoom in/out the camera — [rubric row](../Rubric/Dungeon.md#row-54).
- `Overworld!B32`: Minimap — [rubric row](../Rubric/Overworld.md#row-32).
- `Overworld!B37`: Rotate camera — [rubric row](../Rubric/Overworld.md#row-37).
- `Overworld!B40`: Show/unshow minimap — [rubric row](../Rubric/Overworld.md#row-40).
- `Overworld!B43`: Zoom in/out the camera — [rubric row](../Rubric/Overworld.md#row-43).
- `Battle!B77`: Rotate camera — [rubric row](../Rubric/Battle.md#row-77).
- `Battle!B82`: Rotate camera — [rubric row](../Rubric/Battle.md#row-82).
