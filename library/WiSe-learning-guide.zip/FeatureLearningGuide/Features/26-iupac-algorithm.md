# The shared molecule and dungeon naming algorithm

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `IUPAC Algorithm`, `Dungeon`, `Minigame`.

## What is shared

`BerdlyMolecule` stores nodes (carbons/rooms), undirected bonds (connections/doors), and drawing coordinates. `BerdlyChemistry` generates questions and names graphs. DungeonLayout reuses SelectChain/Name to divide a dungeon into chains and name it.

The code follows the project's alkane/alkyl notation, including its hyphen before the parent alkane. This chapter explains that implementation, not a claim to cover every chemical IUPAC rule or molecule type.

## Building a question graph

A random walk collects unique grid points. Adjacent grid points get random-weight edges. Kruskal sorts them and joins only different disjoint sets, creating a connected acyclic carbon tree. Question generation rejects unsuitable/simple-branch limits with bounded retries and has a known fallback tree.

## Naming, step by step

1. `BestPath` considers possible endpoints within the selected component.
2. Prefer the longest chain, then branch/locant tie-breaks.
3. For the top-level chain consider orientation so branch locants favor the earlier/lower arrangement.
4. For each off-chain connected component, recursively call NamePart from its attachment root.
5. Group identical branch names, collect their one-based positions, and apply multiplier prefixes.
6. Sort branch-name groups and append the parent alkane from the naming table.
7. A nested branch name is wrapped in parentheses using the project's recursive notation.

The maximum selected chain is 11. `LongestChainLength` uses tree-distance searches to detect the diameter length, but the actual tie-breaking chain selection comes from BestPath. Do not confuse the longest-length helper with the full numbering algorithm.

## A small worked example

Imagine a five-carbon parent path with a one-carbon side branch at the second carbon. The table supplies `pentane` and `methyl`; numbering gives locant 2; the project's naming output is `2-methyl-pentane`. Reversing that drawing must still prefer locant 2 over 4. Drawing coordinates do not define the name: bonds do.

## Wrong answers

MakeQuestion creates nearby graph mutations by adding one carbon, names them, removes duplicates/correct matches, and shuffles three distractors plus the correct answer. Very small molecules supplement distractors with nearby alkanes. Distractors are generated data, not four hardcoded button labels.

Dungeon “degree 1” is the parent naming chain; degree 2/3 means recursively nested branch chains, not carbon bond degree.

## Scripts to read

- [BerdlyMolecule.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMolecule.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/BerdlyMolecule.cs).
- [DungeonLayout.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Dungeon/DungeonLayout.cs>) — [included copy](../Scripts/Assets/Scripts/Dungeon/DungeonLayout.cs).
- [BerdlyMoleculeView.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMoleculeView.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/BerdlyMoleculeView.cs).

## Small piece of the actual code

From [BerdlyMolecule.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/BerdlyMolecule.cs:205>) (line 205). This is an excerpt; continue in the full script for context.

```csharp
string NamePart(BerdlyMolecule molecule, HashSet<int> included, int root)
{
    var chain = BestPath(molecule, included, root);
    if (chain.Count > MaximumChain)
        throw new ArgumentException("The longest carbon chain cannot exceed " + MaximumChain + ".");
    var groups = new SortedDictionary<string, List<int>>(StringComparer.Ordinal);
    var onChain = new HashSet<int>(chain);
    for (int i = 0; i < chain.Count; i++)
        foreach (int neighbour in molecule.Bonds[chain[i]])
        {
            if (!included.Contains(neighbour) || onChain.Contains(neighbour)) continue;
            var branch = Component(molecule, neighbour, included, onChain);
            string name = NamePart(molecule, branch, neighbour);
            if (!groups.TryGetValue(name, out var positions)) groups[name] = positions = new List<int>();
            positions.Add(i + 1);
        }
    if (groups.Count == 0) return root < 0 ? alkanes[chain.Count - 1] : alkyls[chain.Count - 1];
```

## Demonstrate it yourself

Trace a hand-built simple branched graph through BestPath, Component, NamePart, and the name tables. Explain chain length, direction, branch grouping, and final formatting. Compare the dungeon name with its room/door graph.

## Explain it in one answer

“The bonds define a tree. We select and number a parent chain, recursively name off-chain components, group repeated branches, then format the name from the supplied tables.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Dungeon!B8`: IUPAC Naming Algorithm — [rubric row](../Rubric/Dungeon.md#row-8).
- `Minigame!B18`: IUPAC Algorithm — [rubric row](../Rubric/Minigame.md#row-18).
- `Minigame!B19`: Molecule generation — [rubric row](../Rubric/Minigame.md#row-19).
- `Minigame!B20`: Multiple choice answer making — [rubric row](../Rubric/Minigame.md#row-20).
- `IUPAC Algorithm!B5`: Determine longest chain (Degree-1) — [rubric row](../Rubric/IUPAC-Algorithm.md#row-5).
- `IUPAC Algorithm!B6`: Determine numbering order of the chain — [rubric row](../Rubric/IUPAC-Algorithm.md#row-6).
- `IUPAC Algorithm!B7`: Determine other degree (Degree-n+1) — [rubric row](../Rubric/IUPAC-Algorithm.md#row-7).
- `IUPAC Algorithm!B8`: Naming algorithm — [rubric row](../Rubric/IUPAC-Algorithm.md#row-8).
