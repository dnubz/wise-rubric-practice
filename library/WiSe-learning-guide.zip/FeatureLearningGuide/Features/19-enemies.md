# Enemy FSM, navigation, Skeleton/Minion attacks, and variants

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Enemies`.

## What an FSM is

A finite state machine chooses one named state and performs that state's behavior. Your encounter enemy has Idle, Patrol, Chase, Attack, and OutOfSight. Transitions reset relevant timers and pending attack impact.

| State | Behavior and exit |
| --- | --- |
| Idle | Waits stationary; after three seconds, tries a patrol destination. |
| Patrol | Moves toward a seeded random reachable point near home; returns to Idle on arrival/timeout. |
| Chase | Repaths toward the detected player. |
| Attack | Stops, faces the player, winds up, and checks/launches an impact. |
| OutOfSight | Stops and visibly searches left/right; returns to Idle after about 1.5 seconds. |

## Navigation and detection

NavMeshAgent follows valid paths rather than walking in a straight line through obstacles. Patrol samples a random point within home radius and requires a complete path. Chase is not restricted to that patrol radius. Detection considers height/range, with extra tracking tolerance. A line-of-sight ray rejects blocked attacks. Water terrain is excluded from generated exploration navigation.

## What starts combat

Skeleton's actual melee impact must overlap the active character. Minion launches EncounterProjectile; actual projectile collision starts the battle. Moving out of range or behind a blocker can cancel/intercept the hit. Merely seeing the enemy is not itself the battle trigger.

## Battle variants

Veterans are larger/purple with enemy red highlighting. Skeleton veteran attacks three times with post-defense scales 1, 0.5, and 0.25. Minion veteran fires two projectiles. Damage has a minimum of one, so tiny later hits still deal one.

BattleEnemyMotion handles procedural sword/body/recoil feedback around the imported models. Settings provide attack/laser sounds. Stable encounter identities let BattleSession remember defeated enemies across chunk reloads and saves.

For FSM explanation, name both the **condition** that changes state and the **action** performed in the state. Listing five labels alone does not explain the machine.

## Scripts to read

- [EncounterEnemy.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/EncounterEnemy.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/EncounterEnemy.cs).
- [EncounterProjectile.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/EncounterProjectile.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/EncounterProjectile.cs).
- [EnemySpawner.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/EnemySpawner.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/EnemySpawner.cs).
- [ExplorationNavigation.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/ExplorationNavigation.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/ExplorationNavigation.cs).
- [BattleEnemyData.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleEnemyData.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleEnemyData.cs).
- [BattleEnemyMotion.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleEnemyMotion.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleEnemyMotion.cs).
- [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleController.cs).

## Small piece of the actual code

From [EncounterEnemy.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/EncounterEnemy.cs:98>) (line 98). This is an excerpt; continue in the full script for context.

```csharp
void SetState(State value)
{
    if (CurrentState == value) return;
    CurrentState = value; timer = 0; nextPath = 0; impactAt = -1;
    if (value == State.OutOfSight) confusedFacing = transform.rotation;
    if (value == State.Idle || value == State.OutOfSight) StopMoving();
}
bool TryPatrolDestination(out Vector3 point)
```

## Demonstrate it yourself

Watch an idle enemy patrol. Enter detection range, then attack range. Move behind a solid obstacle and observe confusion/attack cancellation. In battle, compare normal and veteran attack counts and cover interception.

## Explain it in one answer

“The FSM separates waiting, roaming, pursuing, attacking, and searching. NavMesh supplies reachable motion, and actual melee/projectile hits trigger combat.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Enemies!B7`: Highlighted with red — [rubric row](../Rubric/Enemies.md#row-7).
- `Enemies!B8`: Enemy's state — [rubric row](../Rubric/Enemies.md#row-8).
- `Enemies!B9`: Finite State Machine — [rubric row](../Rubric/Enemies.md#row-9).
- `Enemies!B14`: Attack (Overworld) — [rubric row](../Rubric/Enemies.md#row-14).
- `Enemies!B15`: Attack (Battle) — [rubric row](../Rubric/Enemies.md#row-15).
- `Enemies!B16`: Moving toward player — [rubric row](../Rubric/Enemies.md#row-16).
- `Enemies!B17`: Variant — [rubric row](../Rubric/Enemies.md#row-17).
- `Enemies!B22`: Attack — [rubric row](../Rubric/Enemies.md#row-22).
- `Enemies!B23`: Attack (Battle) — [rubric row](../Rubric/Enemies.md#row-23).
- `Enemies!B24`: Moving toward player — [rubric row](../Rubric/Enemies.md#row-24).
- `Enemies!B25`: Variant — [rubric row](../Rubric/Enemies.md#row-25).
- `Enemies!B30`: Animation — [rubric row](../Rubric/Enemies.md#row-30).
- `Enemies!B31`: SFX — [rubric row](../Rubric/Enemies.md#row-31).
