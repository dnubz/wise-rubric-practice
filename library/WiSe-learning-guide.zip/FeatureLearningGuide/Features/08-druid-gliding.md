# Druid: jumping, slow falling, and the pool cliff

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Characters`, `Overworld`.

## What the player does

Space first performs the ordinary jump. Holding Space while airborne slows Druid's fall. Releasing it restores normal falling behavior.

## How it works

`Druid.Update` reads whether Jump is held and calls `CharacterMovement.SetFloating` with the configured glide fall speed (class default 0.35). CharacterMovement owns the vertical-motion implementation. Druid disables root motion so animation does not override the controller position.

On disable, Druid clears the floating flag and disables its actions. This matters when switching characters: the next character must not inherit a stuck glide state.

## The current pool obstacle

`PoolGlideCliff` exposes a landing BoxCollider and tests whether the player is grounded, above its summit, and not swimming. `Chest.RequireDruidLanding` assigns that cliff test. Despite its method name, this path does not check the character is Druid: any character satisfying Supports can interact. This is the current implementation used at pool centers.

The project instructions require a **boat** at the center of each 5×5 pool and a chest on its deck. The cliff is a confirmed mismatch with that requirement, even though it creates a Druid challenge. See the water chapter and gaps checklist.

## What to explain

Gliding is a movement modifier, not free-flight controls. Druid still jumps, falls, and collides with the world. The controller decides when floating can affect vertical speed; the Druid component supplies the held-button intent.

## Scripts to read

- [Druid.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Character/Druid.cs>) — [included copy](../Scripts/Assets/Scripts/Character/Druid.cs).
- [CharacterMovement.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/CharacterInput/CharacterMovement.cs>) — [included copy](../Scripts/Assets/Scripts/CharacterInput/CharacterMovement.cs).
- [PoolGlideCliff.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolGlideCliff.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/PoolGlideCliff.cs).
- [Chest.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs>) — [included copy](../Scripts/Assets/Scripts/Interactable/Chest.cs).

## Small piece of the actual code

From [Druid.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Character/Druid.cs:34>) (line 34). This is an excerpt; continue in the full script for context.

```csharp
private void Update()
{
    // The first press performs the normal jump. Holding it in the air slows the fall.
    movement.SetFloating(jumpAction != null && jumpAction.IsPressed(), glideFallSpeed);
}

```

## Demonstrate it yourself

Jump with Druid and hold Space, then repeat while releasing it early. Compare falling speed with WiSe. Test the pool landing condition without describing the existing cliff as the required boat.

## Explain it in one answer

“Druid forwards the held jump action to CharacterMovement. The controller reduces falling speed while airborne, and switching off Druid clears that modifier.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Characters!B30`: Druid can float while holding jump button — [rubric row](../Rubric/Characters.md#row-30).
