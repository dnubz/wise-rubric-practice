# Jevil dialogue, summoning, kidnapping, and five dodge patterns

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Boss Battle`.

## Before the fight

Approaching the boss opens BattleBossDialogue. F completes/advances its text. The battle session then enters the boss version of BattleScene with its music, group, and Jevil unit.

## Jevil's turn

The controller chooses the nearest living party target, summons ordinary enemies, relocates Jevil on valid ground, and attempts to place the target near him. It then chooses one of five heart-dodging patterns in BattleBossGame.

## Five patterns (human numbering)

| Pattern | Implementation |
| --- | --- |
| 1 | Jevil fires a five-spade fan toward the heart from outside the arena. |
| 2 | A heart bomb tracks briefly, then splits into four moving rotating hearts. |
| 3 | Four scythes remain as one formation with individual inner motion, outer orbit, and blade spin. |
| 4 | Ten spades around the boundary launch toward center in alternating sequence order. |
| 5 | Rapid spades rise from randomized bottom positions. |

Code uses pattern indices 0–4. Each pattern runs for up to ten seconds or until the target dies. WASD moves the heart within the UI box. Projectile motion has a 1.5× multiplier independent of heart speed.

## Collision and damage

Most projectiles compare distance with the heart. Scythes use blade/handle segment checks so transparent sprite corners are safe. A hit calls `victim.Damage(boss.Attack, 1 + enemies/100f)`. BattleUnit subtracts defense before scaling and applies the one-damage minimum; a shield may block the hit.

After a hit the heart has 1.5 seconds of invincibility and flashes. The panel hides and all bullets return to their pools when the sequence ends. Pools reuse UI Images rather than instantiating/destroying every wave repeatedly.

The saved MovementBox has square sizing in the existing presentation notes; verify it visually at the target screen resolution. An old Cheats.md statement that Jevil is unimplemented is stale relative to these current scripts.

## Scripts to read

- [BattleBossDialogue.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossDialogue.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleBossDialogue.cs).
- [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleController.cs).
- [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleBossGame.cs).
- [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleUnit.cs).

## Small piece of the actual code

From [BattleBossGame.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleBossGame.cs:91>) (line 91). This is an excerpt; continue in the full script for context.

```csharp
if (invincible <= 0 && hit)
{ victim.Damage(boss.Attack, 1 + enemies / 100f); invincible = 1.5f; }
```

## Demonstrate it yourself

Reach the boss, advance dialogue with F, and observe summons/kidnapping. Demonstrate each pattern through the existing editor fixture or repeated turns. Point out heart bounds, blade-shaped scythe collision, and the flashing invincibility window.

## Explain it in one answer

“Jevil's turn combines 3D summoning/kidnapping with a timed UI dodge game. Each pattern updates pooled projectiles, and hit checks apply party damage followed by a short invincibility window.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Boss Battle!B7`: Battle transition — [rubric row](../Rubric/Boss-Battle.md#row-7).
- `Boss Battle!B8`: Boss dialogue — [rubric row](../Rubric/Boss-Battle.md#row-8).
- `Boss Battle!B9`: Skip dialogue with F — [rubric row](../Rubric/Boss-Battle.md#row-9).
- `Boss Battle!B14`: Jevil summoning enemies — [rubric row](../Rubric/Boss-Battle.md#row-14).
- `Boss Battle!B15`: Jevil's kidnap player — [rubric row](../Rubric/Boss-Battle.md#row-15).
- `Boss Battle!B16`: Jevil's attack pattern 1 — [rubric row](../Rubric/Boss-Battle.md#row-16).
- `Boss Battle!B17`: Jevil's attack pattern 2 — [rubric row](../Rubric/Boss-Battle.md#row-17).
- `Boss Battle!B18`: Jevil's attack pattern 3 — [rubric row](../Rubric/Boss-Battle.md#row-18).
- `Boss Battle!B19`: Jevil's attack pattern 4 — [rubric row](../Rubric/Boss-Battle.md#row-19).
- `Boss Battle!B20`: Jevil's attack pattern 5 — [rubric row](../Rubric/Boss-Battle.md#row-20).
- `Boss Battle!B21`: Heart movement — [rubric row](../Rubric/Boss-Battle.md#row-21).
- `Boss Battle!B22`: Collision handling — [rubric row](../Rubric/Boss-Battle.md#row-22).
- `Boss Battle!B23`: Damage formula — [rubric row](../Rubric/Boss-Battle.md#row-23).
- `Boss Battle!B24`: Invincibility — [rubric row](../Rubric/Boss-Battle.md#row-24).
