# Druid battle skills: healing burst, pull, teleport, and rhythm

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Skills`.

## Four abilities

Druid.cs supplies exploration floating. BattleController's `characterIndex == 2` branch supplies combat effects.

| Slot/key | Behavior |
| --- | --- |
| Basic / 1 | Radiant Chorus bursts at the aimed point, damages enemies, and heals living allies within radius. |
| First skill / 2 | Enrapturing Melody pulls initially selected enemies toward Druid over five sequence seconds. |
| Second skill / 3 | Resonant Passage bursts at departure and arrival, teleports to clear valid NavMesh ground, and resets movement origin. |
| Ultimate / 4 | Grand Ensemble reveals Mario/Pink, starts the shared shorter rhythm chart, and uses resulting accuracy for enemy charm/stun probability. |

## Damage and healing

Basic damage uses magic-adjusted `20 + round(Attack × 0.9)` and healing uses `27 + round(Attack × 1.13)`. Teleport bursts use magic-adjusted `14 + round(Attack × 0.7)` damage and `30 + round(Attack × 1.2)` heal. Burst applies each effect separately to live targets within its circle.

Teleport confirmation checks NavMesh position and nearby units. The displayed range clamps the aim. You cannot confirm an occupied/invalid destination merely because it appears inside the circle.

## Pull mechanics

The controller captures targets inside the initial radius, then repeatedly calls PullTowards. Forced movement also shifts their movement origin so the later range clamp does not snap them back. The five-second effect follows sequence speed, so fast-forward can shorten its real duration.

## Ultimate sequence

Grand Ensemble hides Druid's original renderers, spawns the performance model, reframes the camera, faces enemies toward it, and stops the introductory sound before the rhythm countdown. PinkRhythmController runs the battle beatmap and returns accuracy. Each living enemy gets a random test against that accuracy; a successful test sets stun to one, causing it to skip an enemy action. Camera and renderers are restored afterward.

Druid's ultimate unlock comes from Pink rhythm completion with at least 84,000 score (or `lastday`). The battle performance still needs its own live timing demonstration.

## Scripts to read

- [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleController.cs).
- [BattleUnit.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleUnit.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleUnit.cs).
- [BattleSkill.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleSkill.cs>) — [included copy](../Scripts/Assets/Scripts/Battle/BattleSkill.cs).
- [PinkRhythmController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/PinkRhythmController.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/PinkRhythmController.cs).
- [PinkRhythmRules.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/UI/InGame/PinkRhythmRules.cs>) — [included copy](../Scripts/Assets/Scripts/UI/InGame/PinkRhythmRules.cs).

## Small piece of the actual code

From [BattleController.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Battle/BattleController.cs:272>) (line 272). This is an excerpt; continue in the full script for context.

```csharp
int damage = Magic(actor, 14 + Mathf.RoundToInt(attack * .7f)), heal = 30 + Mathf.RoundToInt(attack * 1.2f);
Burst(actor, actor.transform.position, skill.radius, damage, heal); actor.Agent.Warp(point); actor.ResetMovement(); Burst(actor, point, skill.radius, damage, heal);
```

## Demonstrate it yourself

Show a basic circle containing both an ally and enemy. Pull enemies, teleport to clear ground, then try an occupied point. With Grand Ensemble unlocked, play the short rhythm sequence and show camera restoration and skipped enemy actions.

## Explain it in one answer

“Druid's circles affect allies and enemies differently. Pull updates forced movement safely, teleport checks valid landing space, and the ultimate converts rhythm accuracy into enemy stun chances.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Skills!B84`: Circular area — [rubric row](../Rubric/Skills.md#row-84).
- `Skills!B85`: Damaging enemy — [rubric row](../Rubric/Skills.md#row-85).
- `Skills!B86`: Heal ally — [rubric row](../Rubric/Skills.md#row-86).
- `Skills!B87`: Skill indicator — [rubric row](../Rubric/Skills.md#row-87).
- `Skills!B92`: Circle area of effect — [rubric row](../Rubric/Skills.md#row-92).
- `Skills!B93`: Skill visual effect — [rubric row](../Rubric/Skills.md#row-93).
- `Skills!B94`: All enemies in area were pulled toward druid for 5 seconds — [rubric row](../Rubric/Skills.md#row-94).
- `Skills!B99`: Heal allies & damage enemies before and after teleportation — [rubric row](../Rubric/Skills.md#row-99).
- `Skills!B100`: Teleporting — [rubric row](../Rubric/Skills.md#row-100).
- `Skills!B101`: Visual effect — [rubric row](../Rubric/Skills.md#row-101).
- `Skills!B102`: Only can teleport within area — [rubric row](../Rubric/Skills.md#row-102).
- `Skills!B107`: Unlock criteria — [rubric row](../Rubric/Skills.md#row-107).
- `Skills!B108`: Cutscene before rhythm game — [rubric row](../Rubric/Skills.md#row-108).
- `Skills!B109`: Camera — [rubric row](../Rubric/Skills.md#row-109).
- `Skills!B110`: Enemy facing — [rubric row](../Rubric/Skills.md#row-110).
- `Skills!B111`: Rhythm minigame — [rubric row](../Rubric/Skills.md#row-111).
- `Skills!B112`: Parse Beatmap — [rubric row](../Rubric/Skills.md#row-112).
- `Skills!B113`: Stun — [rubric row](../Rubric/Skills.md#row-113).
- `Skills!B118`: Animation — [rubric row](../Rubric/Skills.md#row-118).
- `Skills!B119`: SFX — [rubric row](../Rubric/Skills.md#row-119).
