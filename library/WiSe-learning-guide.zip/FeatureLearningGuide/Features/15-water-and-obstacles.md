# 5×5 pools, swimming, obstacle chests, and the boat mismatch

[Guide home](../README.md) · [Controls](../01-controls.md) · [Script index](../ScriptReference/README.md)

**Workbook areas:** `Overworld`.

## Water has two parts

The selected WaterTerrain prefab remains the pool bed. The painter changes its runtime TerrainData to create depth, and WaterSurfaceBuilder adds a separate water surface. CharacterMovement uses WFC water plus surface/depth checks to select swimming. Water terrain is excluded from enemy navigation.

## Pool size and shore

Each selected pool is exactly five tiles wide and deep. Its full footprint including the sand ring and grass/rock ring needs a chunk of at least nine tiles. Water can touch water inside the pool. The boundary must follow water → sand → grass/rock even at diagonals.

The midpoint of the pool bounds is the center of tile (3,3), counting from one. With default ten-meter tiles, the water area is 50×50 meters.

## Confirmed unmet boat requirement

Despite its name, `PoolBoatContent.Create` loads `Interaction/PoolGlideCliff`, places a rock summit at the midpoint, and puts a chest on it with a grounded summit-landing check. `RequireDruidLanding` is the method name, but that path does not enforce a Druid type check. It does **not** instantiate the assigned boat prefab. WFCWorldManager still has boat prefab/scale/deck-offset fields, but this creation path does not use them.

Your instruction requires a boat at that midpoint and an openable chest on its deck. The cliff implementation fails those boat/deck requirements. The guide records the actual behavior and leaves the game code unchanged.

## Chest progress

PoolBoatContent keeps an opened-chunk HashSet outside the temporary chunk hierarchy. Creating the chunk again restores opened state. `Chest.Opened` records the chunk when the interaction succeeds, and GameSave serializes that list.

The platform obstacle has a separate opened-chest set and an authored platform prefab. Its chest is aligned to the final platform and requires a valid platform landing. Chest seeds use stable world/chunk identity, so loot rolls do not depend on scene instance IDs.

## Surface sound gap

SurfaceAudioSettings defines distinct grass/sand/rock clips and swimming splashes. `WalkingClip(1)` falls back to rock; there is no distinct water walking clip. Swimming audio is present, but the strict requirement for a distinct walking sound for **each of four types** is not fully represented.

## Scripts to read

- [WFCWorldManager.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WFCWorldManager.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/WFCWorldManager.cs).
- [WaterSurfaceBuilder.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/WaterSurfaceBuilder.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/WaterSurfaceBuilder.cs).
- [BlendedChunkTerrain.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/BlendedChunkTerrain.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/BlendedChunkTerrain.cs).
- [PoolBoatContent.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolBoatContent.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/PoolBoatContent.cs).
- [PoolGlideCliff.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolGlideCliff.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/PoolGlideCliff.cs).
- [OverworldObstacleSpawner.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/OverworldObstacleSpawner.cs).
- [OverworldPlatformObstacle.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/OverworldPlatformObstacle.cs>) — [included copy](../Scripts/Assets/Scripts/Terrain/OverworldPlatformObstacle.cs).
- [Chest.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/Chest.cs>) — [included copy](../Scripts/Assets/Scripts/Interactable/Chest.cs).
- [LootTable.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Interactable/LootTable.cs>) — [included copy](../Scripts/Assets/Scripts/Interactable/LootTable.cs).

## Small piece of the actual code

From [PoolBoatContent.cs](<C:/Users/Ezell/WiSe/Assets/Scripts/Terrain/PoolBoatContent.cs:27>) (line 27). This is an excerpt; continue in the full script for context.

```csharp
// The midpoint is the center of tile (3,3) in a 5x5 pool.
Vector3 centre = new Vector3((pool.x + pool.z) * 0.5f, waterHeight, (pool.y + pool.w) * 0.5f);
var cliffPrefab = Resources.Load<PoolGlideCliff>("Interaction/PoolGlideCliff");
if (cliffPrefab == null) { Debug.LogError("Missing saved pool cliff prefab."); return; }
var cliff = Object.Instantiate(cliffPrefab, centre, Quaternion.identity, parent);
cliff.name = "Druid Glide Cliff " + chunk;
cliff.Place(new System.Random(WorldRandom.Seed(seed, chunk.x, chunk.y, 0x434C4946)));
Physics.SyncTransforms();

Vector3 summit = new Vector3(centre.x, cliff.TopHeight, centre.z);
```

## Demonstrate it yourself

Locate a pool, inspect its 5×5 water and two rings, swim, and open the center chest if its grounded summit-landing check allows. Leave the chunk and return to check opened state. Inspect the actual center object and explain the boat mismatch explicitly.

## Explain it in one answer

“The pool bed stays Unity Terrain and swimming uses a separate surface. Opened chest IDs survive chunk reloads. Currently the center object is a glide cliff, so the required boat/deck behavior is unmet.”

## Exact workbook requirements covered here

The row number is the source locator. The rubric file preserves recorded scores separately.

- `Overworld!B18`: Obstacle 1 — [rubric row](../Rubric/Overworld.md#row-18).
- `Overworld!B19`: Obstacle 2 — [rubric row](../Rubric/Overworld.md#row-19).
