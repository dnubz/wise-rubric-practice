using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Uniform chalk outlines and bonds; atom labels are reused between questions.</summary>
[RequireComponent(typeof(CanvasRenderer))]
public sealed class BerdlyMoleculeView : MaskableGraphic
{
    readonly List<TextMeshProUGUI> labels = new List<TextMeshProUGUI>();
    BerdlyMolecule molecule;
    Vector2[] points;
    float cell;
    TMP_FontAsset labelFont;
    static readonly Color ChalkColor = new Color(1f, .9f, .36f, 1f);

    public void Show(BerdlyMolecule value, TMP_FontAsset font)
    {
        molecule = value; labelFont = font; raycastTarget = false;
        while (labels.Count < molecule.Count)
        {
            var obj = new GameObject("Carbon", typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            obj.transform.SetParent(transform, false);
            var label = obj.GetComponent<TextMeshProUGUI>();
            label.alignment = TextAlignmentOptions.Center;
            label.raycastTarget = false;
            labels.Add(label);
        }
        for (int i = 0; i < labels.Count; i++)
        {
            labels[i].gameObject.SetActive(i < molecule.Count);
            if (i >= molecule.Count) continue;
            if (labelFont != null) labels[i].font = labelFont;
            // No chain/branch colours or numbering hints: every carbon uses the same chalk.
            labels[i].color = ChalkColor;
            int hydrogens = 4 - molecule.Bonds[i].Count;
            labels[i].text = hydrogens == 0 ? "C" : hydrogens == 1 ? "CH" : "CH" + hydrogens;
        }
        LayoutAtoms(); SetVerticesDirty();
    }

    protected override void OnRectTransformDimensionsChange()
    {
        base.OnRectTransformDimensionsChange();
        if (molecule != null) LayoutAtoms();
    }

    void LayoutAtoms()
    {
        var rect = rectTransform.rect;
        int minX = int.MaxValue, minY = int.MaxValue, maxX = int.MinValue, maxY = int.MinValue;
        foreach (var p in molecule.Positions)
        { minX = Mathf.Min(minX, p.x); maxX = Mathf.Max(maxX, p.x); minY = Mathf.Min(minY, p.y); maxY = Mathf.Max(maxY, p.y); }
        cell = Mathf.Max(1, Mathf.Min(80f, rect.width / (maxX - minX + 1.2f), rect.height / (maxY - minY + 1.2f)));
        points = new Vector2[molecule.Count];
        var center = new Vector2((minX + maxX) * .5f, (minY + maxY) * .5f);
        for (int i = 0; i < molecule.Count; i++)
        {
            points[i] = ((Vector2)molecule.Positions[i] - center) * cell + rect.center;
            var label = labels[i];
            label.rectTransform.anchorMin = label.rectTransform.anchorMax = new Vector2(.5f, .5f);
            label.rectTransform.anchoredPosition = points[i] - rect.center;
            label.rectTransform.sizeDelta = Vector2.one * cell * .65f;
            label.fontSize = Mathf.Clamp(cell * .23f, 8, 24);
        }
    }

    protected override void OnPopulateMesh(VertexHelper mesh)
    {
        mesh.Clear();
        if (molecule == null || points == null) return;
        Color32 bondColor = new Color(.91f, .93f, .86f, 1f);
        Color32 atomColor = ChalkColor;
        for (int a = 0; a < molecule.Count; a++)
            foreach (int b in molecule.Bonds[a])
            {
                if (b <= a) continue;
                Vector2 direction = (points[b] - points[a]).normalized;
                Vector2 normal = new Vector2(-direction.y, direction.x) * Mathf.Max(1.5f, cell * .025f);
                Vector2 start = points[a] + direction * cell * .30f;
                Vector2 end = points[b] - direction * cell * .30f;
                int index = mesh.currentVertCount;
                mesh.AddVert(start - normal, bondColor, Vector2.zero); mesh.AddVert(start + normal, bondColor, Vector2.zero);
                mesh.AddVert(end + normal, bondColor, Vector2.zero); mesh.AddVert(end - normal, bondColor, Vector2.zero);
                mesh.AddTriangle(index, index + 1, index + 2); mesh.AddTriangle(index, index + 2, index + 3);
            }
        for (int i = 0; i < molecule.Count; i++)
        {
            int index = mesh.currentVertCount;
            float radius = cell * .30f;
            float inner = Mathf.Max(0, radius - Mathf.Max(1.5f, cell * .035f));
            for (int segment = 0; segment < 20; segment++)
            {
                float angle = segment * Mathf.PI * 2f / 20;
                Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
                mesh.AddVert(points[i] + direction * radius, atomColor, Vector2.zero);
                mesh.AddVert(points[i] + direction * inner, atomColor, Vector2.zero);
            }
            for (int segment = 0; segment < 20; segment++)
            {
                int a = index + segment * 2, b = index + (segment + 1) % 20 * 2;
                mesh.AddTriangle(a, a + 1, b); mesh.AddTriangle(b, a + 1, b + 1);
            }
        }
    }
}
