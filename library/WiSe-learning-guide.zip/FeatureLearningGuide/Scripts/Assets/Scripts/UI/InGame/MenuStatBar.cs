using UnityEngine;
using UnityEngine.UI;

// Keep the full bar rectangle fixed; only its visible fill changes.
public static class MenuStatBar
{
    static Sprite white;

    public static void Set(Image image, int current, int maximum)
    {
        if (image == null) return;
        if (image.type != Image.Type.Filled && image.transform.parent is RectTransform track &&
            (track.name == "HPBar" || track.name == "ManaBar"))
        {
            // Restore older menu instances whose previous script already shortened the rectangle.
            var rect = image.rectTransform;
            rect.anchorMin = new Vector2(0, .5f); rect.anchorMax = new Vector2(1, .5f);
            rect.pivot = Vector2.one * .5f; rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(-53.7f, 15.1f);
        }
        // Unity ignores Image.fillAmount when no sprite is assigned.
        if (image.sprite == null)
        {
            if (white == null)
            {
                var texture = Texture2D.whiteTexture;
                white = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one * .5f);
                white.name = "Menu stat fill"; white.hideFlags = HideFlags.HideAndDontSave;
            }
            image.sprite = white;
        }
        image.type = Image.Type.Filled;
        image.fillMethod = Image.FillMethod.Horizontal;
        image.fillOrigin = (int)Image.OriginHorizontal.Left;
        image.fillAmount = maximum > 0 ? Mathf.Clamp01((float)current / maximum) : 0;
    }
}
