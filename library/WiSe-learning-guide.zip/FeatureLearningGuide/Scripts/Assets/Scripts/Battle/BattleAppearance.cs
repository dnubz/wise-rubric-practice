using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public sealed class BattleAppearance : MonoBehaviour
{
    readonly List<Renderer> renderers = new List<Renderer>();
    readonly List<bool> originalEnabled = new List<bool>();
    readonly List<Material[]> originals = new List<Material[]>(), copies = new List<Material[]>();
    bool ready;
    public void Prepare()
    {
        if (ready) return; ready = true;
        GetComponent<ObjectHighlight>()?.EnableHighlight();
        foreach (var renderer in GetComponentsInChildren<Renderer>(true))
        {
            if (!(renderer is MeshRenderer) && !(renderer is SkinnedMeshRenderer)) continue;
            var source = renderer.sharedMaterials; var duplicate = new Material[source.Length];
            for (int i = 0; i < source.Length; i++) if (source[i] != null) duplicate[i] = new Material(source[i]);
            renderers.Add(renderer); originalEnabled.Add(renderer.enabled); originals.Add(source); copies.Add(duplicate); renderer.sharedMaterials = duplicate;
        }
    }
    public void Show(float alpha = 1, bool stone = false)
    {
        Prepare();
        bool veteran = TryGetComponent<BattleUnit>(out var unit) && unit.variant;
        for (int r = 0; r < copies.Count; r++)
        {
            if (renderers[r] == null) continue;
            renderers[r].enabled = originalEnabled[r] && !(renderers[r].name.StartsWith("[Outline]") && (alpha < 1 || stone));
            for (int i = 0; i < copies[r].Length; i++)
            {
                var material = copies[r][i]; var source = originals[r][i]; if (material == null || source == null) continue;
                string key = material.HasProperty("_BaseColor") ? "_BaseColor" : "_Color";
                var color = source.HasProperty(key) ? source.GetColor(key) : Color.white;
                if (veteran && !renderers[r].name.StartsWith("[Outline]")) color = new Color(.7f, .25f, .85f);
                if (stone) color = new Color(.42f, .44f, .47f); color.a = alpha;
                if (material.HasProperty(key)) material.SetColor(key, color);
                if (material.HasProperty("_Surface")) material.SetFloat("_Surface", alpha < 1 ? 1 : 0);
                if (material.HasProperty("_SrcBlend")) material.SetFloat("_SrcBlend", alpha < 1 ? (float)BlendMode.SrcAlpha : (float)BlendMode.One);
                if (material.HasProperty("_DstBlend")) material.SetFloat("_DstBlend", alpha < 1 ? (float)BlendMode.OneMinusSrcAlpha : (float)BlendMode.Zero);
                if (material.HasProperty("_ZWrite")) material.SetFloat("_ZWrite", alpha < 1 ? 0 : 1);
                if (alpha < 1) material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT"); else material.DisableKeyword("_SURFACE_TYPE_TRANSPARENT");
                material.renderQueue = alpha < 1 ? (int)RenderQueue.Transparent : source.renderQueue;
            }
        }
    }
    public void Restore()
    {
        for (int i = 0; i < renderers.Count; i++) if (renderers[i] != null) { renderers[i].sharedMaterials = originals[i]; renderers[i].enabled = originalEnabled[i]; }
        foreach (var set in copies) foreach (var material in set) if (material != null) Destroy(material);
        renderers.Clear(); originalEnabled.Clear(); originals.Clear(); copies.Clear(); ready = false;
    }
    void OnDestroy() => Restore();
}
