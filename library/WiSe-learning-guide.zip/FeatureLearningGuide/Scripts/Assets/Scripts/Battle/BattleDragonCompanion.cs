using UnityEngine;

// Keeps the replaceable flying prefab beside WiSe throughout the battle.
public sealed class BattleDragonCompanion : MonoBehaviour
{
    BattleUnit owner;
    Vector3? aim;
    public Transform Mouth { get; private set; }
    public void Bind(BattleUnit unit)
    {
        owner = unit; Mouth = GetComponent<BattleDragonVisual>().mouth;
        Follow();
    }
    public void Aim(Vector3 point) { aim = point; Follow(); }
    public void StopAiming() => aim = null;
    void LateUpdate()
    {
        if (owner == null || BattleSession.MenuOpen) return;
        if (!owner.Alive) { gameObject.SetActive(false); return; }
        Follow();
    }
    void Follow()
    {
        transform.position = owner.transform.position + Vector3.up * 4.2f + owner.transform.right * 2.1f - owner.transform.forward;
        Vector3 forward = aim.HasValue ? aim.Value - transform.position : owner.transform.forward;
        forward.y = 0;
        if (forward.sqrMagnitude > .001f) transform.rotation = Quaternion.LookRotation(forward);
    }
}
