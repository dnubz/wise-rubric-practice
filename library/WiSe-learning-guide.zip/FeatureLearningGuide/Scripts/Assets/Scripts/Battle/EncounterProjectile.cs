using UnityEngine;

public sealed class EncounterProjectile : MonoBehaviour
{
    public EncounterEnemy owner;
    public Vector3 destination;
    Vector3 direction;
    float elapsed;
    void Start() { direction = (destination - transform.position).normalized; }
    void Update()
    {
        if (BattleSession.IsActive) { Destroy(gameObject); return; }
        if (NPCChallengePrompt.BlocksGameplayInput || CheatConsole.BlocksGameplayInput) return;
        if (owner == null || !owner.isActiveAndEnabled) { Destroy(gameObject); return; }
        float step = 12 * Time.deltaTime; elapsed += Time.deltaTime;
        var hits = Physics.SphereCastAll(transform.position, .18f, direction, step, ~0, QueryTriggerInteraction.Ignore);
        System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));
        foreach (var hit in hits)
        {
            if (owner == null || hit.collider.transform.IsChildOf(owner.transform)) continue;
            if (hit.collider.GetComponentInParent<CharacterBase>() != null) BattleSession.Instance?.Begin(owner);
            Destroy(gameObject); return;
        }
        transform.position += direction * step; if (elapsed > 5) Destroy(gameObject);
    }
}
