using UnityEngine;

public sealed class BattleCrescentVisual : MonoBehaviour
{
    public LineRenderer sweep;
    public float duration = .32f;
    float elapsed;
    void Update()
    {
        if (BattleSession.MenuOpen) return;
        elapsed += Time.deltaTime * (BattleController.Instance != null ? BattleController.Instance.SequenceSpeed : 1);
        float progress = Mathf.Clamp01(elapsed / duration);
        float head = Mathf.Lerp(-90, 90, progress), tail = Mathf.Max(-90, head - 70);
        for (int i = 0; i < sweep.positionCount; i++)
        {
            float angle = Mathf.Lerp(tail, head, (float)i / (sweep.positionCount - 1)) * Mathf.Deg2Rad;
            sweep.SetPosition(i, new Vector3(Mathf.Sin(angle), 0, Mathf.Cos(angle)));
        }
        sweep.widthMultiplier = Mathf.Lerp(.32f, .05f, progress);
        if (progress >= 1) Destroy(gameObject);
    }
}
