using System;
using System.Collections.Generic;

/// <summary>Small seeded WFC: collapse the smallest set, then propagate neighbour constraints.</summary>
public static class DungeonFloorWFC
{
    // Brick and slab can touch anything. Moss is isolated and cannot touch cracked tiles.
    static readonly int[] Neighbours = { 15, 15, 7, 3 };
    static readonly int[] Weights = { 50, 30, 14, 6 };

    public static int[] Generate(int width, int depth, int seed)
    {
        if (width < 1 || depth < 1) throw new ArgumentOutOfRangeException(nameof(width));
        var random = new Random(seed);
        var cells = new int[width * depth];
        var queue = new Queue<int>();
        for (int z = 0; z < depth; z++)
            for (int x = 0; x < width; x++)
            {
                // The edge and central crossing stay clear stone for doorways and spawn points.
                bool clear = x == 0 || z == 0 || x == width - 1 || z == depth - 1 ||
                    Math.Abs(x - (width - 1) / 2f) < 1 || Math.Abs(z - (depth - 1) / 2f) < 1;
                cells[z * width + x] = clear ? 3 : 15;
                if (clear) queue.Enqueue(z * width + x);
            }
        Propagate(cells, width, depth, queue);
        while (true)
        {
            int chosen = -1, lowest = 5, ties = 0;
            for (int i = 0; i < cells.Length; i++)
            {
                int count = Count(cells[i]);
                if (count <= 1 || count > lowest) continue;
                if (count < lowest) { lowest = count; ties = 0; }
                if (random.Next(++ties) == 0) chosen = i;
            }
            if (chosen < 0) break;
            int total = 0;
            for (int tile = 0; tile < 4; tile++) if ((cells[chosen] & (1 << tile)) != 0) total += Weights[tile];
            int roll = random.Next(total);
            for (int tile = 0; tile < 4; tile++)
                if ((cells[chosen] & (1 << tile)) != 0)
                {
                    roll -= Weights[tile];
                    if (roll < 0) { cells[chosen] = 1 << tile; break; }
                }
            queue.Enqueue(chosen); Propagate(cells, width, depth, queue);
        }
        var result = new int[cells.Length];
        for (int i = 0; i < cells.Length; i++)
            for (int tile = 0; tile < 4; tile++) if (cells[i] == 1 << tile) result[i] = tile;
        return result;
    }

    static void Propagate(int[] cells, int width, int depth, Queue<int> queue)
    {
        while (queue.Count > 0)
        {
            int index = queue.Dequeue(), allowed = 0;
            for (int tile = 0; tile < 4; tile++) if ((cells[index] & (1 << tile)) != 0) allowed |= Neighbours[tile];
            int x = index % width, z = index / width;
            if (x > 0) Reduce(cells, index - 1, allowed, queue);
            if (x + 1 < width) Reduce(cells, index + 1, allowed, queue);
            if (z > 0) Reduce(cells, index - width, allowed, queue);
            if (z + 1 < depth) Reduce(cells, index + width, allowed, queue);
        }
    }
    static void Reduce(int[] cells, int index, int allowed, Queue<int> queue)
    {
        int reduced = cells[index] & allowed;
        if (reduced == 0) throw new InvalidOperationException("Dungeon floor WFC has no valid tile.");
        if (reduced != cells[index]) { cells[index] = reduced; queue.Enqueue(index); }
    }
    static int Count(int mask)
    {
        int count = 0; while (mask != 0) { mask &= mask - 1; count++; } return count;
    }
}
