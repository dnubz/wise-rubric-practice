using System;

[Serializable]
public class InventorySlot
{
    private Item item;

    public Item Item => item;

    public InventorySlot(Item item)
    {
        this.item = item;
    }
}