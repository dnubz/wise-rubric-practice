using UnityEngine;

public abstract class Item : ScriptableObject
{
    [SerializeField] private string itemName;
    [SerializeField] private Sprite icon;
    [TextArea]
    [SerializeField] private string description;

    public string ItemName => itemName;
    public Sprite Icon => icon;
    public string Description => description;
    
    // Override this in subclasses if they have a specific cost field
    public virtual int Cost => 0;

    public virtual void Use()
    {
        Debug.Log($"Using {itemName}");
    }
}