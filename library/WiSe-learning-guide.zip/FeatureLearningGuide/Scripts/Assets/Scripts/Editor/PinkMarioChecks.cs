using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

[InitializeOnLoad]
public static class PinkMarioChecks
{
    const string Folder = "Temp/PinkMario";
    static double nextCheck;
    static PinkMarioChecks() { EditorApplication.update += Check; }
    static void Check()
    {
        if (EditorApplication.timeSinceStartup < nextCheck || EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode) return;
        nextCheck = EditorApplication.timeSinceStartup + 1;
        if (!File.Exists(Folder + "/check.request")) return;
        File.Delete(Folder + "/check.request");
        try { Run(); File.WriteAllText(Folder + "/check-result.txt", "PASS: Mario model/materials, full Rainbow Road chart with holds, song/countdown assignments, ordered countdown cues and isolated preview camera."); }
        catch (Exception error) { File.WriteAllText(Folder + "/check-result.txt",error.ToString()); Debug.LogException(error); }
    }
    [MenuItem("WiSe/Validate Pink Mario Model and Audio")]
    public static void Run()
    {
        Directory.CreateDirectory(Folder);
        var pink = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/Pink.prefab");
        var importer = (ModelImporter)AssetImporter.GetAtPath("Assets/Imported Assets/MarioN64/MarioSmoothed.fbx");
        Require(!importer.importCameras && !importer.importLights && pink.GetComponentsInChildren<Camera>(true).Length == 0,
            "Mario's modelling camera can override the player camera.");
        Require(pink.GetComponent<MinigameNPC>().Kind == MinigameNPC.MinigameKind.PinkRhythm && pink.transform.Find("MarioN64Visual") != null,
            "Pink NPC lost its challenge behavior or Mario visual.");
        var visible = pink.GetComponentsInChildren<Renderer>().Where(r => r.enabled).ToArray();
        Require(visible.Length > 0 && visible.All(r => r.transform.IsChildOf(pink.transform.Find("MarioN64Visual"))), "The old Pink mesh is still visible.");
        Require(visible.SelectMany(r => r.sharedMaterials).All(m => m != null && m.shader.name == "Universal Render Pipeline/Lit" && m.GetTexture("_BaseMap") != null), "Mario has untextured or incompatible materials.");
        Scene scene = SceneManager.GetSceneByPath("Assets/Scenes/GameScene.unity");
        var controller = scene.GetRootGameObjects().SelectMany(r => r.GetComponentsInChildren<PinkRhythmController>(true)).First();
        var fields = new SerializedObject(controller);
        var song = (AudioClip)fields.FindProperty("song").objectReferenceValue;
        var countdown = (AudioClip)fields.FindProperty("countdownSound").objectReferenceValue;
        var countdownSource = (AudioSource)fields.FindProperty("countdownSource").objectReferenceValue;
        var map = PinkBeatmap.Parse(((TextAsset)fields.FindProperty("pinkBeatmap").objectReferenceValue).text);
        Require(song.name.Contains("Rainbow Road") && countdown.name.Contains("Mario 3 2 1 Go") && countdownSource != null,
            "The supplied audio is not assigned.");
        Require(map.Notes.Length == 553 && map.Notes.Count(n => n.IsHold) == 25 && map.AudioStartSeconds + map.Notes.Max(n => n.End) < song.length,
            "The new song is shorter than its assigned chart.");
        Vector3 cues = fields.FindProperty("countdownNumberCueSeconds").vector3Value;
        float go = fields.FindProperty("countdownGoSeconds").floatValue;
        Require(cues.x < cues.y && cues.y < cues.z && cues.z < go && go < countdown.length,
            "Countdown numbers and GO are not ordered inside the recording.");
        var stage = (GameObject)fields.FindProperty("pinkStage").objectReferenceValue;
        bool active = stage.activeSelf; stage.SetActive(true);
        Camera camera = stage.GetComponentInChildren<Camera>();
        RenderTexture previous = RenderTexture.active;
        try
        {
            Require(stage.transform.Find("PinkModel").name == "PinkModel" && stage.GetComponentsInChildren<Renderer>().Length > 0,
                "The rhythm-stage Mario model is missing.");
            Require(stage.GetComponentsInChildren<Camera>(true).Length == 1 && camera.targetTexture != null,
                "The rhythm stage must have only its assigned render-texture camera.");
            camera.ResetWorldToCameraMatrix(); camera.ResetProjectionMatrix(); camera.Render();
            RenderTexture.active = camera.targetTexture;
            var image = new Texture2D(camera.targetTexture.width,camera.targetTexture.height,TextureFormat.RGBA32,false);
            image.ReadPixels(new Rect(0,0,image.width,image.height),0,0); image.Apply();
            File.WriteAllBytes(Folder + "/mario.png",image.EncodeToPNG()); Object.DestroyImmediate(image);
        }
        finally { RenderTexture.active = previous; stage.SetActive(active); }
    }
    static void Require(bool value,string message) { if (!value) throw new InvalidOperationException(message); }
}
