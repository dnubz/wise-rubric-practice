using UnityEngine;

// Identifies terrain decorations that a building may safely clear.
public sealed class GeneratedResourceMarker : MonoBehaviour
{
    public bool IsDecoration;
}
