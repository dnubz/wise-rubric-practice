using UnityEngine;
using System;

[CreateAssetMenu(
    fileName = "IntEventChannel",
    menuName = "Events/Int Event Channel"
)]
public class IntEventChannel : ScriptableObject
{
    public event Action<int> OnEventRaised;

    public void RaiseEvent(int value)
    {
        OnEventRaised?.Invoke(value);
    }
}