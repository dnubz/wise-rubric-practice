# Documentation checks

[Guide home](README.md)

- markdown files: 85.
- feature chapters: 32.
- rubric sheets: 19.
- requirement rows: 330.
- source scripts: 226.
- configured assets: 42.
- links checked: 4500.
- broken links: 0.
- runtime tests: not run (documentation task).

Each source copy was checked against its original SHA-256. All workbook feature rows have a teaching route. This validates documentation structure and copies, not runtime feature completion.
